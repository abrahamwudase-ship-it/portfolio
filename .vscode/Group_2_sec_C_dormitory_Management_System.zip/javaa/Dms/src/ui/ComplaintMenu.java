package ui;

import exception.InvalidInputException;
import exception.StudentNotFoundException;
import file.FileManager;
import model.Student;
import service.ComplaintService;
import service.StudentService;

import java.util.Scanner;

/**
 * ComplaintMenu — handles all complaint management screens.
 *
 * Sub-menu:
 *   ┌─────────────────────────────────────┐
 *   │        COMPLAINT MANAGEMENT         │
 *   ├─────────────────────────────────────┤
 *   │  1. Submit New Complaint            │
 *   │  2. View All Complaints             │
 *   │  3. View Complaints by Student      │
 *   │  4. View Complaint Details          │
 *   │  5. Mark Complaint In Progress      │
 *   │  6. Resolve Complaint               │
 *   │  7. Back to Main Menu               │
 *   └─────────────────────────────────────┘
 */
public class ComplaintMenu {

    private ComplaintService complaintService;
    private StudentService   studentService;
    private FileManager      fileManager;
    private Scanner          scanner;

    public ComplaintMenu(ComplaintService complaintService,
                         StudentService   studentService,
                         FileManager      fileManager,
                         Scanner          scanner) {
        this.complaintService = complaintService;
        this.studentService   = studentService;
        this.fileManager      = fileManager;
        this.scanner          = scanner;
    }

    // ── Main Loop ──────────────────────────────────────────────────────────

    public void run() {
        boolean running = true;

        while (running) {
            printComplaintMenu();

            try {
                int choice = readInt("  Enter your choice: ");

                switch (choice) {
                    case 1: submitComplaint();        break;
                    case 2: viewAllComplaints();      break;
                    case 3: viewByStudent();          break;
                    case 4: viewComplaintDetails();   break;
                    case 5: markInProgress();         break;
                    case 6: resolveComplaint();       break;
                    case 7: running = false;          break;
                    default:
                        throw new InvalidInputException("Please enter 1–7.");
                }

            } catch (InvalidInputException e) {
                System.out.println("  [INPUT ERROR] " + e.getMessage());
            }
        }
    }

    // ── 1. Submit Complaint ────────────────────────────────────────────────

    private void submitComplaint() {
        System.out.println("\n  ════════ SUBMIT NEW COMPLAINT ════════");

        System.out.print("  Enter your Student ID: ");
        String sid = scanner.nextLine().trim();

        Student student = null;
        try {
            student = studentService.findById(sid);
        } catch (StudentNotFoundException e) {
            System.out.println("  [ERROR] " + e.getMessage());
            pause();
            return;
        }

        // FIX: was getAssignedRoomNumber() which returns -1 when room label is "G01"
        // because Integer.parseInt("G01") fails and returns -1.
        // Now correctly uses getAssignedRoomLabel() which returns null when unassigned.
        String roomLabel = student.getAssignedRoomLabel();
        if (roomLabel == null || roomLabel.isEmpty()) {
            System.out.println("  [ERROR] You have not been assigned a room yet.");
            pause();
            return;
        }

        System.out.println("  Student  : " + student.getFullName());
        System.out.println("  Block    : " + student.getAssignedBlockName());
        System.out.println("  Room     : " + roomLabel);
        System.out.print("  Describe your complaint: ");
        String description = scanner.nextLine().trim();

        if (description.isEmpty()) {
            System.out.println("  [ERROR] Complaint description cannot be empty.");
            pause();
            return;
        }

        // FIX: pass roomLabel (String) not roomNo (int)
        complaintService.addComplaint(sid, student.getFullName(), roomLabel, description);
        student.setHasComplaint(true);
        fileManager.saveComplaints(
                complaintService.getComplaints(), complaintService.getComplaintCount());
        pause();
    }

    // ── 2. View All Complaints ─────────────────────────────────────────────

    private void viewAllComplaints() {
        System.out.println("\n  ════════ ALL COMPLAINTS ════════");
        complaintService.displayAllComplaints();
        pause();
    }

    // ── 3. View by Student ─────────────────────────────────────────────────

    private void viewByStudent() {
        System.out.print("\n  Enter Student ID: ");
        String sid = scanner.nextLine().trim();
        System.out.println();
        complaintService.displayComplaintsByStudent(sid);
        pause();
    }

    // ── 4. View Complaint Details ──────────────────────────────────────────

    private void viewComplaintDetails() {
        System.out.print("\n  Enter Complaint ID (e.g. C001): ");
        String cid = scanner.nextLine().trim();
        model.Complaint c = complaintService.findById(cid);
        if (c == null) {
            System.out.println("  [NOT FOUND] Complaint " + cid + " does not exist.");
        } else {
            System.out.println();
            c.displayComplaint();
        }
        pause();
    }

    // ── 5. Mark In Progress ────────────────────────────────────────────────

    private void markInProgress() {
        System.out.print("\n  Enter Complaint ID to mark IN PROGRESS: ");
        String cid = scanner.nextLine().trim();
        complaintService.setInProgress(cid);
        fileManager.saveComplaints(
                complaintService.getComplaints(), complaintService.getComplaintCount());
        pause();
    }

    // ── 6. Resolve Complaint ───────────────────────────────────────────────

    private void resolveComplaint() {
        System.out.print("\n  Enter Complaint ID to resolve: ");
        String cid = scanner.nextLine().trim();
        System.out.print("  Enter resolution note: ");
        String note = scanner.nextLine().trim();
        complaintService.resolveComplaint(cid, note);
        fileManager.saveComplaints(
                complaintService.getComplaints(), complaintService.getComplaintCount());
        pause();
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private void printComplaintMenu() {
        System.out.println();
        System.out.println("  ╔═══════════════════════════════════════════╗");
        System.out.println("  ║          COMPLAINT MANAGEMENT             ║");
        System.out.println("  ╠═══════════════════════════════════════════╣");
        System.out.println("  ║  1. Submit New Complaint                  ║");
        System.out.println("  ║  2. View All Complaints                   ║");
        System.out.println("  ║  3. View Complaints by Student            ║");
        System.out.println("  ║  4. View Complaint Details                ║");
        System.out.println("  ║  5. Mark Complaint In Progress            ║");
        System.out.println("  ║  6. Resolve Complaint                     ║");
        System.out.println("  ║  7. Back to Main Menu                     ║");
        System.out.println("  ╚═══════════════════════════════════════════╝");
    }

    private int readInt(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Please enter a valid number.");
        }
    }

    private void pause() {
        System.out.print("\n  Press ENTER to continue...");
        scanner.nextLine();
    }
}
