package ui;

import exception.InvalidInputException;
import exception.StudentNotFoundException;
import model.Student;
import service.StudentService;

import java.util.Scanner;

/**
 * StudentMenu handles the student management UI screens.
 */
public class StudentMenu {

    private StudentService studentService;
    private Scanner scanner;

    public StudentMenu(StudentService studentService, Scanner scanner) {
        this.studentService = studentService;
        this.scanner = scanner;
    }

    // ── 1. View All Students ───────────────────────────────────────────────

    public void viewAllStudents() {
        System.out.println("\n  ════════════════════════════════════════════════");
        System.out.println("               ALL STUDENTS (Sorted A–Z)          ");
        System.out.println("  ════════════════════════════════════════════════");
        studentService.displayAllStudents();
        pause();
    }

    // ── 2. Search Student ──────────────────────────────────────────────────

    public void searchStudent() {
        System.out.println("\n  ╔═══════════════════════════════════════╗");
        System.out.println("  ║          SEARCH STUDENT               ║");
        System.out.println("  ╠═══════════════════════════════════════╣");
        System.out.println("  ║  1. Search by Student ID              ║");
        System.out.println("  ║  2. Search by First Name              ║");
        System.out.println("  ║  3. Back                              ║");
        System.out.println("  ╚═══════════════════════════════════════╝");

        try {
            int choice = readInt("  Enter your choice: ");
            switch (choice) {
                case 1: searchById();   break;
                case 2: searchByName(); break;
                case 3: return;
                default: System.out.println("  [ERROR] Invalid choice.");
            }
        } catch (InvalidInputException e) {
            System.out.println("  [INPUT ERROR] " + e.getMessage());
        }
    }

    private void searchById() {
        System.out.print("  Enter Student ID (e.g. S001): ");
        String id = scanner.nextLine().trim();

        try {
            Student s = studentService.findById(id);
            System.out.println();
            s.displayInfo();
        } catch (StudentNotFoundException e) {
            System.out.println("  [NOT FOUND] " + e.getMessage());
        } finally {
            pause();
        }
    }

    private void searchByName() {
        System.out.print("  Enter first name (or part of it): ");
        String name = scanner.nextLine().trim();

        Student[] results = new Student[200];
        int count = studentService.searchByName(name, results, 200);

        if (count == 0) {
            System.out.println("  [NOT FOUND] No students match '" + name + "'.");
        } else {
            System.out.printf("%n  Found %d result(s):%n%n", count);
            for (int i = 0; i < count; i++) {
                results[i].displayInfo();
            }
        }
        pause();
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private int readInt(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Please enter a valid number.");
        }
    }

    private void pause() {
        System.out.print("\n  Press ENTER to continue...");
        scanner.nextLine();
    }
}
