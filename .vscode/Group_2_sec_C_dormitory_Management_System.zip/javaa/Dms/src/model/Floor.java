package model;
 
/**
 * Floor — one storey inside a Block.
 *
 * Rules:
 *  • Each Block has exactly 4 floors (Ground, 1, 2, 3).
 *  • Each Floor contains exactly ROOMS_PER_FLOOR (18) rooms.
 *  • Room labels are auto-generated based on floor number:
 *      Ground → G01 … G18
 *      Floor 1 → 101 … 118
 *      Floor 2 → 201 … 218
 *      Floor 3 → 301 … 318
 *
 * Encapsulation: all fields private, accessed via getters.
 */
public class Floor {
 
    public static final int ROOMS_PER_FLOOR = 18;
 
    // ── Fields ─────────────────────────────────────────────────────────────
    private int    floorNumber;   // 0 = Ground, 1, 2, 3
    private String floorName;     // "Ground Floor", "Floor 1", etc.
    private String blockName;     // parent block
    private String department;    // inherited from block
    private String gender;        // inherited from block
 
    private Room[] rooms;         // exactly ROOMS_PER_FLOOR rooms
 
    // ── Constructor ────────────────────────────────────────────────────────
 
    public Floor(int floorNumber, String blockName, String department, String gender) {
        this.floorNumber = floorNumber;
        this.blockName   = blockName;
        this.department  = department;
        this.gender      = gender;
        this.floorName   = resolveFloorName(floorNumber);
 
        // Auto-create all rooms for this floor
        this.rooms = new Room[ROOMS_PER_FLOOR];
        for (int i = 0; i < ROOMS_PER_FLOOR; i++) {
            String label = buildRoomLabel(floorNumber, i + 1); // rooms 1..18
            rooms[i] = new Room(label, floorNumber, blockName, department, gender);
        }
    }
 
    // ── Getters ────────────────────────────────────────────────────────────
 
    public int    getFloorNumber()  { return floorNumber; }
    public String getFloorName()    { return floorName;   }
    public String getBlockName()    { return blockName;   }
    public String getDepartment()   { return department;  }
    public String getGender()       { return gender;      }
    public Room[] getRooms()        { return rooms;       }
 
    // ── Stats ──────────────────────────────────────────────────────────────
 
    public int getTotalRooms()     { return ROOMS_PER_FLOOR; }
 
    public int getOccupiedRooms() {
        int count = 0;
        for (Room r : rooms) if (r.isFull()) count++;
        return count;
    }
 
    public int getAvailableRooms() {
        int count = 0;
        for (Room r : rooms) if (r.isAvailable()) count++;
        return count;
    }
 
    public int getTotalBeds()      { return ROOMS_PER_FLOOR * Room.MAX_CAPACITY; }
 
    public int getOccupiedBeds() {
        int total = 0;
        for (Room r : rooms) total += r.getOccupantCount();
        return total;
    }
 
    public int getAvailableBeds()  { return getTotalBeds() - getOccupiedBeds(); }
 
    /**
     * Find the first available (not full) room on this floor.
     * Returns null if every room is full.
     */
    public Room findAvailableRoom() {
        for (Room r : rooms) if (r.isAvailable()) return r;
        return null;
    }
 
    /**
     * Find a room on this floor by its label (e.g. "G05", "203").
     */
    public Room findRoomByLabel(String label) {
        for (Room r : rooms) {
            if (r.getLabel().equalsIgnoreCase(label)) return r;
        }
        return null;
    }
 
    // ── Display ────────────────────────────────────────────────────────────
 
    /**
     * Print a compact table of all rooms on this floor.
     */
    public void printFloorTable() {
        System.out.printf("%n  ┌── %s  (%s Block)  ──  %d rooms%n",
                floorName, blockName, ROOMS_PER_FLOOR);
        System.out.println("  │");
        System.out.println("  │  Room   │  Status  │  Beds   │  Free         │");
        System.out.println("  │  ───────┼──────────┼─────────┼───────────────┤");
        for (Room r : rooms) r.printStatusRow();
        System.out.println("  │");
    }
 
    // ── Label Builders ─────────────────────────────────────────────────────
 
    private static String resolveFloorName(int n) {
        switch (n) {
            case 0: return "Ground Floor";
            case 1: return "Floor 1";
            case 2: return "Floor 2";
            case 3: return "Floor 3";
            default: return "Floor " + n;
        }
    }
 
    /**
     * Build room label.
     * Ground floor: G01 … G18
     * Other floors: [floorNo][01] … [floorNo][18]   → 101…118, 201…218, 301…318
     */
    public static String buildRoomLabel(int floorNumber, int roomIndex) {
        if (floorNumber == 0) {
            return String.format("G%02d", roomIndex);
        }
        return String.format("%d%02d", floorNumber, roomIndex);
    }
}