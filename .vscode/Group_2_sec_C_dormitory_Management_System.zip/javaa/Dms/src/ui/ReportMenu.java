package ui;

import exception.InvalidInputException;
import file.FileManager;
import service.ComplaintService;
import service.RoomService;
import service.StudentService;

import java.util.Scanner;

/**
 * ReportMenu — generates student, room, and complaint reports.
 *
 * Sub-menu:
 *   ┌─────────────────────────────────────┐
 *   │           REPORT MODULE             │
 *   ├─────────────────────────────────────┤
 *   │  1. Generate Student Report         │
 *   │  2. Generate Room Report            │
 *   │  3. Generate Complaint Report       │
 *   │  4. Generate Full System Report     │
 *   │  5. Back to Main Menu               │
 *   └─────────────────────────────────────┘
 */
public class ReportMenu {

    private StudentService   studentService;
    private RoomService      roomService;
    private ComplaintService complaintService;
    private FileManager      fileManager;
    private Scanner          scanner;

    public ReportMenu(StudentService studentService,
                      RoomService roomService,
                      ComplaintService complaintService,
                      FileManager fileManager,
                      Scanner scanner) {
        this.studentService   = studentService;
        this.roomService      = roomService;
        this.complaintService = complaintService;
        this.fileManager      = fileManager;
        this.scanner          = scanner;
    }

    // ── Main Loop ──────────────────────────────────────────────────────────

    public void run() {
        boolean running = true;

        while (running) {
            printReportMenu();

            try {
                int choice = readInt("  Enter your choice: ");

                switch (choice) {
                    case 1: generateStudentReport();   break;
                    case 2: generateRoomReport();      break;
                    case 3: generateComplaintReport(); break;
                    case 4: generateFullReport();      break;
                    case 5: running = false;           break;
                    default:
                        throw new InvalidInputException("Please enter 1–5.");
                }

            } catch (InvalidInputException e) {
                System.out.println("  [INPUT ERROR] " + e.getMessage());
            }
        }
    }

    // ── 1. Student Report ──────────────────────────────────────────────────

    private void generateStudentReport() {
        System.out.println("\n  Generating student report...");
        String report = studentService.generateStudentReport();
        System.out.println(report);
        fileManager.writeReport("student_report.txt", report);
        pause();
    }

    // ── 2. Room Report ─────────────────────────────────────────────────────

    private void generateRoomReport() {
        System.out.println("\n  Generating room report...");
        String report = roomService.generateRoomReport();
        System.out.println(report);
        fileManager.writeReport("room_report.txt", report);
        pause();
    }

    // ── 3. Complaint Report ────────────────────────────────────────────────

    private void generateComplaintReport() {
        System.out.println("\n  Generating complaint report...");
        String report = complaintService.generateComplaintReport();
        System.out.println(report);
        fileManager.writeReport("complaint_report.txt", report);
        pause();
    }

    // ── 4. Full System Report ──────────────────────────────────────────────

    private void generateFullReport() {
        System.out.println("\n  Generating full system report...");

        String fullReport =
            "╔══════════════════════════════════════════════════╗\n" +
            "║      ETHIOPIAN UNIVERSITY DORMITORY SYSTEM       ║\n" +
            "║              FULL SYSTEM REPORT                  ║\n" +
            "╚══════════════════════════════════════════════════╝\n\n" +
            studentService.generateStudentReport() + "\n" +
            roomService.generateRoomReport()       + "\n" +
            complaintService.generateComplaintReport();

        System.out.println(fullReport);
        fileManager.writeReport("full_system_report.txt", fullReport);
        pause();
    }

    // ── Helpers ────────────────────────────────────────────────────────────

    private void printReportMenu() {
        System.out.println();
        System.out.println("  ╔═══════════════════════════════════════════╗");
        System.out.println("  ║              REPORT MODULE                ║");
        System.out.println("  ╠═══════════════════════════════════════════╣");
        System.out.println("  ║  1. Generate Student Report               ║");
        System.out.println("  ║  2. Generate Room Report                  ║");
        System.out.println("  ║  3. Generate Complaint Report             ║");
        System.out.println("  ║  4. Generate Full System Report           ║");
        System.out.println("  ║  5. Back to Main Menu                     ║");
        System.out.println("  ╚═══════════════════════════════════════════╝");
    }

    private int readInt(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Please enter a valid number.");
        }
    }

    private void pause() {
        System.out.print("\n  Press ENTER to continue...");
        scanner.nextLine();
    }
}
