package service;

import model.Complaint;
import model.Complaint.Status;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * ComplaintService handles all complaint-related operations.
 */
public class ComplaintService {

    private static final int MAX_COMPLAINTS = 500;
    private Complaint[] complaints;
    private int complaintCount;
    private int nextId;

    public ComplaintService() {
        complaints = new Complaint[MAX_COMPLAINTS];
        complaintCount = 0;
        nextId = 1;
    }

    public Complaint[] getComplaints() { return complaints; }
    public int getComplaintCount()     { return complaintCount; }

    public void setComplaints(Complaint[] loaded, int count) {
        this.complaintCount = count;
        for (int i = 0; i < count; i++) {
            complaints[i] = loaded[i];
        }
        // Set nextId beyond highest existing
        for (int i = 0; i < count; i++) {
            try {
                int n = Integer.parseInt(
                        complaints[i].getComplaintId().replace("C", ""));
                if (n >= nextId) nextId = n + 1;
            } catch (NumberFormatException ignored) {}
        }
    }

    // FIX: parameter changed from int roomNumber -> String roomLabel
    public void addComplaint(String studentId, String studentName,
                             String roomLabel, String description) {
        String id = String.format("C%03d", nextId++);
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        complaints[complaintCount++] =
                new Complaint(id, studentId, studentName, roomLabel, description, date);
        System.out.println("  [OK] Complaint " + id + " submitted successfully.");
    }

    public void displayAllComplaints() {
        if (complaintCount == 0) {
            System.out.println("  No complaints on record.");
            return;
        }
        System.out.println("+-----------+----------------------+--------+-------------+------------+");
        System.out.println("|    ID     |       Student        |  Room  |   Status    |    Date    |");
        System.out.println("+-----------+----------------------+--------+-------------+------------+");
        for (int i = 0; i < complaintCount; i++) {
            Complaint c = complaints[i];
            // FIX: was c.getRoomNumber() int — now c.getRoomLabel() String
            System.out.printf("| %-8s  | %-20s |  %-5s | %-11s | %-10s |%n",
                    c.getComplaintId(), c.getStudentName(),
                    c.getRoomLabel(), c.getStatus(), c.getDateSubmitted());
        }
        System.out.println("+-----------+----------------------+--------+-------------+------------+");
    }

    public void displayComplaintsByStudent(String studentId) {
        boolean found = false;
        for (int i = 0; i < complaintCount; i++) {
            if (complaints[i].getStudentId().equalsIgnoreCase(studentId)) {
                complaints[i].displayComplaint();
                found = true;
            }
        }
        if (!found) System.out.println("  No complaints found for student " + studentId);
    }

    public Complaint findById(String complaintId) {
        for (int i = 0; i < complaintCount; i++) {
            if (complaints[i].getComplaintId().equalsIgnoreCase(complaintId))
                return complaints[i];
        }
        return null;
    }

    public void resolveComplaint(String complaintId, String note) {
        Complaint c = findById(complaintId);
        if (c == null) {
            System.out.println("  [ERROR] Complaint " + complaintId + " not found.");
            return;
        }
        c.setStatus(Status.RESOLVED);
        c.setResolutionNote(note);
        System.out.println("  [OK] Complaint " + complaintId + " marked as RESOLVED.");
    }

    public void setInProgress(String complaintId) {
        Complaint c = findById(complaintId);
        if (c == null) {
            System.out.println("  [ERROR] Complaint " + complaintId + " not found.");
            return;
        }
        c.setStatus(Status.IN_PROGRESS);
        System.out.println("  [OK] Complaint " + complaintId + " marked as IN_PROGRESS.");
    }

    public String generateComplaintReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("================================================\n");
        sb.append("     COMPLAINT REPORT - DORMITORY SYSTEM        \n");
        sb.append("================================================\n");
        sb.append(String.format("Total Complaints : %d%n%n", complaintCount));

        int pending = 0, inProgress = 0, resolved = 0;
        for (int i = 0; i < complaintCount; i++) {
            switch (complaints[i].getStatus()) {
                case PENDING:     pending++;     break;
                case IN_PROGRESS: inProgress++;  break;
                case RESOLVED:    resolved++;    break;
            }
        }
        sb.append(String.format("Pending     : %d%n", pending));
        sb.append(String.format("In Progress : %d%n", inProgress));
        sb.append(String.format("Resolved    : %d%n%n", resolved));

        for (int i = 0; i < complaintCount; i++) {
            sb.append(complaints[i].getSummary()).append("\n");
        }
        return sb.toString();
    }
}
