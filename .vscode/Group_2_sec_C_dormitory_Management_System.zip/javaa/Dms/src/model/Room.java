package model;
 
import exception.RoomFullException;
 
/**
 * Room — one physical room inside a Floor.
 *
 * Room label format:
 *   Ground floor  →  G01 … G18
 *   Floor 1       →  101 … 118
 *   Floor 2       →  201 … 218
 *   Floor 3       →  301 … 318
 *
 * Max capacity: 6 students per room.
 * Encapsulation: all fields private, accessed via getters/setters.
 */
public class Room implements Reportable {
 
    public static final int MAX_CAPACITY = 6;
 
    // ── Fields ─────────────────────────────────────────────────────────────
    private String    label;          // e.g. "G01", "101", "215"
    private int       floorNumber;    // 0 = Ground, 1, 2, 3
    private String    blockName;      // parent block name
    private String    department;     // inherited from block
    private String    gender;         // "M" or "F" — inherited from block
 
    private Student[] occupants;      // fixed-size array, max 6
    private int       occupantCount;
 
    // ── Constructor ────────────────────────────────────────────────────────
 
    public Room(String label, int floorNumber,
                String blockName, String department, String gender) {
        this.label         = label;
        this.floorNumber   = floorNumber;
        this.blockName     = blockName;
        this.department    = department;
        this.gender        = gender;
        this.occupants     = new Student[MAX_CAPACITY];
        this.occupantCount = 0;
    }
 
    // ── Getters & Setters (Encapsulation) ──────────────────────────────────
 
    public String  getLabel()        { return label; }
    public int     getFloorNumber()  { return floorNumber; }
    public String  getBlockName()    { return blockName; }
    public String  getDepartment()   { return department; }
    public String  getGender()       { return gender; }
    public Student[] getOccupants()  { return occupants; }
    public int     getOccupantCount(){ return occupantCount; }
    public int     getAvailableBeds(){ return MAX_CAPACITY - occupantCount; }
    public boolean isAvailable()     { return occupantCount < MAX_CAPACITY; }
    public boolean isFull()          { return occupantCount >= MAX_CAPACITY; }
 
    // ── Core Operation ─────────────────────────────────────────────────────
 
    /**
     * Assign a student to this room.
     * @throws RoomFullException if room is already at capacity
     */
    public void assignStudent(Student s) throws RoomFullException {
        if (isFull()) throw new RoomFullException(label, MAX_CAPACITY);
        occupants[occupantCount++] = s;
        s.setAssignedRoom(label, blockName);
    }
 
    /**
     * Remove a student from this room (used for re-allocation or removal).
     * Returns true if student was found and removed.
     */
    public boolean removeStudent(String studentId) {
        for (int i = 0; i < occupantCount; i++) {
            if (occupants[i].getId().equals(studentId)) {
                // Shift left
                for (int j = i; j < occupantCount - 1; j++) {
                    occupants[j] = occupants[j + 1];
                }
                occupants[occupantCount - 1] = null;
                occupantCount--;
                return true;
            }
        }
        return false;
    }
 
    public boolean containsStudent(String studentId) {
        for (int i = 0; i < occupantCount; i++) {
            if (occupants[i] != null && occupants[i].getId().equals(studentId)) return true;
        }
        return false;
    }
 
    // ── Display ────────────────────────────────────────────────────────────
 
    /**
     * Print a compact one-line status row (used inside floor tables).
     */
    public void printStatusRow() {
        System.out.printf("  │  %-5s  │  %-6s  │  %d / %d  │  %d beds left  │%n",
                label,
                isAvailable() ? "OPEN" : "FULL",
                occupantCount, MAX_CAPACITY,
                getAvailableBeds());
    }
 
    /**
     * Print the full detail card for this room including all occupants.
     */
    public void printDetailCard() {
        String gLabel = gender.equals("M") ? "Male" : "Female";
        System.out.println("  ┌────────────────────────────────────────────────────────────┐");
        System.out.printf ("  │  Room: %-8s  Block: %-12s  Floor: %-12s│%n",
                label, blockName, floorLabel());
        System.out.printf ("  │  Department: %-20s  Gender: %-14s│%n", department, gLabel);
        System.out.println("  ├────────────────────────────────────────────────────────────┤");
 
        if (occupantCount == 0) {
            System.out.println("  │  (No students assigned to this room yet)                   │");
        } else {
            System.out.println("  │  OCCUPANTS:                                                │");
            for (int i = 0; i < occupantCount; i++) {
                Student st = occupants[i];
                System.out.printf("  │   %d. %-20s  [%s]  Yr %d  %-12s│%n",
                        i + 1,
                        st.getFullName(),
                        st.getId(),
                        st.getYearOfStudy(),
                        "");
            }
        }
        System.out.println("  └────────────────────────────────────────────────────────────┘");
    }
 
    // ── Reportable ─────────────────────────────────────────────────────────
 
    @Override
    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Room %-5s | Block %-10s | Floor %-10s | %s",
                label, blockName, floorLabel(),
                isAvailable() ? "Available" : "Full"));
        sb.append("\n");
        for (int i = 0; i < occupantCount; i++) {
            sb.append(String.format("    %d. %-22s [%s]\n",
                    i + 1, occupants[i].getFullName(), occupants[i].getId()));
        }
        return sb.toString();
    }
 
    @Override
    public String getSummary() {
        return String.format("Room %-5s | %s",
                label, isAvailable() ? "Available" : "Full");
    }
 
    // ── Helpers ────────────────────────────────────────────────────────────
 
    private String floorLabel() {
        switch (floorNumber) {
            case 0: return "Ground Floor";
            case 1: return "Floor 1";
            case 2: return "Floor 2";
            case 3: return "Floor 3";
            default: return "Floor " + floorNumber;
        }
    }
 
    /**
     * Visual bed occupancy bar  e.g.  [■■■□□□]
     */
    private String buildBedBar() {
        StringBuilder bar = new StringBuilder("[");
        for (int i = 0; i < MAX_CAPACITY; i++) {
            bar.append(i < occupantCount ? "■" : "□");
        }
        bar.append("]");
        return bar.toString();
    }
}