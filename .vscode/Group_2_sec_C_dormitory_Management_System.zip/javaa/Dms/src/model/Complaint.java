package model;

/**
 * Complaint class representing a dormitory complaint submitted by a student.
 */
public class Complaint {

    public enum Status { PENDING, IN_PROGRESS, RESOLVED }

    private String complaintId;
    private String studentId;
    private String studentName;
    private String roomLabel;      // FIX: was int roomNumber — now String roomLabel ("G01", "205")
    private String description;
    private Status status;
    private String dateSubmitted;
    private String resolutionNote;

    // FIX: constructor parameter changed from int roomNumber -> String roomLabel
    public Complaint(String complaintId, String studentId, String studentName,
                     String roomLabel, String description, String dateSubmitted) {
        this.complaintId    = complaintId;
        this.studentId      = studentId;
        this.studentName    = studentName;
        this.roomLabel      = roomLabel;
        this.description    = description;
        this.status         = Status.PENDING;
        this.dateSubmitted  = dateSubmitted;
        this.resolutionNote = "";
    }

    // Getters & Setters
    public String getComplaintId()   { return complaintId; }
    public String getStudentId()     { return studentId; }
    public String getStudentName()   { return studentName; }
    public String getRoomLabel()     { return roomLabel; }   // FIX: was getRoomNumber() int
    public String getDescription()   { return description; }
    public Status getStatus()        { return status; }
    public void   setStatus(Status status) { this.status = status; }
    public String getDateSubmitted() { return dateSubmitted; }
    public String getResolutionNote(){ return resolutionNote; }
    public void   setResolutionNote(String note) { this.resolutionNote = note; }

    public void displayComplaint() {
        System.out.println("+---------------------------------------------------------+");
        System.out.printf("|  Complaint ID  : %-40s |%n", complaintId);
        System.out.printf("|  Student       : %-40s |%n", studentName + " (" + studentId + ")");
        System.out.printf("|  Room          : %-40s |%n", roomLabel);   // FIX
        System.out.printf("|  Date          : %-40s |%n", dateSubmitted);
        System.out.printf("|  Status        : %-40s |%n", status);
        System.out.printf("|  Description   : %-40s |%n", description);
        if (!resolutionNote.isEmpty()) {
            System.out.printf("|  Resolution    : %-40s |%n", resolutionNote);
        }
        System.out.println("+---------------------------------------------------------+");
    }

    public String toCSV() {
        return complaintId + "|" + studentId + "|" + studentName + "|"
                + roomLabel + "|" + description + "|" + status + "|"   // FIX
                + dateSubmitted + "|" + resolutionNote;
    }

    public static Complaint fromCSV(String line) {
        String[] parts = line.split("\\|", -1);
        if (parts.length < 8) return null;

        // FIX: parts[3] is now a String room label — no more Integer.parseInt()
        Complaint c = new Complaint(
            parts[0], parts[1], parts[2],
            parts[3],   // roomLabel as String directly
            parts[4], parts[6]
        );
        c.setStatus(Status.valueOf(parts[5]));
        c.setResolutionNote(parts[7]);
        return c;
    }

    public String getSummary() {
        // FIX: was "Room %-3d" with int — now "Room %-5s" with String
        return String.format("%-8s | %-20s | Room %-5s | %-11s | %s",
                complaintId, studentName, roomLabel, status, dateSubmitted);
    }
}
