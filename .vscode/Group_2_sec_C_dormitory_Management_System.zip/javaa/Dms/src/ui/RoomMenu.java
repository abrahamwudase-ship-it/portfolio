package ui;
 
import exception.DepartmentMismatchException;
import exception.GenderMismatchException;
import exception.InvalidInputException;
import exception.RoomFullException;
import exception.StudentNotFoundException;
import model.Block;
import model.Floor;
import model.Room;
import model.Student;
import service.AllocationService;
import service.StudentService;
import file.FileManager;
 
import java.util.Scanner;
 
/**
 * RoomMenu — the complete Block & Room Management console UI.
 *
 * ╔══════════════════════════════════════════════════╗
 * ║         BLOCK & ROOM MANAGEMENT MENU            ║
 * ╠══════════════════════════════════════════════════╣
 * ║  1. View All Blocks (Overview)                  ║
 * ║  2. View Block Details                          ║
 * ║  3. Browse Male Wing                            ║
 * ║  4. Browse Female Wing                          ║
 * ║  5. View Floor Details                          ║
 * ║  6. View Room Details                           ║
 * ║  7. Assign Student to Room (Manual)             ║
 * ║  8. Block Status Report                         ║
 * ║  9. Room Availability Search                    ║
 * ║  10. Back to Main Menu                          ║
 * ╚══════════════════════════════════════════════════╝
 */
public class RoomMenu {
 
    private AllocationService allocationService;
    private StudentService    studentService;
    private FileManager       fileManager;
    private Scanner           scanner;
 
    public RoomMenu(AllocationService allocationService,
                    StudentService    studentService,
                    FileManager       fileManager,
                    Scanner           scanner) {
        this.allocationService = allocationService;
        this.studentService    = studentService;
        this.fileManager       = fileManager;
        this.scanner           = scanner;
    }
 
    // ── Entry point (called from MainMenu) ────────────────────────────────
 
    public void run() {
        boolean running = true;
        while (running) {
            printMenu();
            try {
                int choice = readInt("  Enter your choice: ");
                System.out.println();
                switch (choice) {
                    case 1:  viewAllBlocks();          break;
                    case 2:  viewBlockDetails();       break;
                    case 3:  browseWing("M");          break;
                    case 4:  browseWing("F");          break;
                    case 5:  viewFloorDetails();       break;
                    case 6:  viewRoomDetails();        break;
                    case 7:  manualAssign();           break;
                    case 8:  blockStatusReport();      break;
                    case 9:  searchAvailableRooms();   break;
                    case 10: running = false;          break;
                    default: throw new InvalidInputException("Please enter 1–10.");
                }
            } catch (InvalidInputException e) {
                System.out.println("  [INPUT ERROR] " + e.getMessage());
            }
        }
    }
 
    // ── 1. View All Blocks ─────────────────────────────────────────────────
 
    private void viewAllBlocks() {
        System.out.println("  ════════════════════════════════════════════════");
        System.out.println("           ALL BLOCKS — SYSTEM OVERVIEW           ");
        System.out.println("  ════════════════════════════════════════════════");
        allocationService.displayAllBlocks();
        pause();
    }
 
    // ── 2. View Block Details ──────────────────────────────────────────────
 
    private void viewBlockDetails() {
        System.out.println("  ════════ BLOCK DETAIL ════════");
        listBlockNames();
        System.out.print("  Enter block name (e.g. Block M-A): ");
        String name = scanner.nextLine().trim();
        System.out.println();
        allocationService.displayBlockDetail(name);
        pause();
    }
 
    // ── 3 & 4. Browse Wing ─────────────────────────────────────────────────
 
    private void browseWing(String gender) {
        String wingTitle = gender.equals("M") ? "MALE WING" : "FEMALE WING";
        boolean running  = true;
 
        while (running) {
            System.out.println();
            System.out.println("  ════════ " + wingTitle + " — DEPARTMENT BLOCKS ════════");
 
            // List blocks for this gender
            Block[] blocks = allocationService.getBlocks();
            int     bc     = allocationService.getBlockCount();
            int     shown  = 0;
 
            System.out.println();
            System.out.printf("  %-4s  %-12s  %-24s  %-8s  %-10s  %-8s%n",
                    "No.", "Block", "Department", "Rooms", "Occupied", "Free");
            System.out.println("  " + "─".repeat(72));
 
            for (int i = 0; i < bc; i++) {
                if (!blocks[i].getGender().equals(gender)) continue;
                shown++;
                System.out.printf("  %-4d  %-12s  %-24s  %-8d  %-10d  %-8d%n",
                        shown,
                        blocks[i].getBlockName(),
                        blocks[i].getDepartment(),
                        blocks[i].getTotalRooms(),
                        blocks[i].getOccupiedBeds(),
                        blocks[i].getAvailableBeds());
            }
 
            if (shown == 0) {
                System.out.println("  (No blocks in this wing)");
                pause();
                return;
            }
 
            System.out.println();
            System.out.println("  Options:  [block number] = open that block   |  0 = back");
            try {
                int pick = readInt("  Choice: ");
                if (pick == 0) { running = false; break; }
                if (pick < 1 || pick > shown)
                    throw new InvalidInputException("Enter 0–" + shown + ".");
 
                // Find the n-th block for this gender
                int count = 0;
                for (int i = 0; i < bc; i++) {
                    if (!blocks[i].getGender().equals(gender)) continue;
                    count++;
                    if (count == pick) {
                        drillIntoBlock(blocks[i]);
                        break;
                    }
                }
            } catch (InvalidInputException e) {
                System.out.println("  [INPUT ERROR] " + e.getMessage());
            }
        }
    }
 
    /** Show a sub-menu for a single block: header | floor list | drill to floor */
    private void drillIntoBlock(Block block) {
        boolean running = true;
        while (running) {
            block.printHeaderCard();
            System.out.println();
            System.out.println("  Floors in " + block.getBlockName() + ":");
            System.out.printf("  %-4s  %-15s  %-10s  %-10s  %-10s%n",
                    "No.", "Floor", "Rooms", "Occupied", "Available");
            System.out.println("  " + "─".repeat(55));
 
            Floor[] floors = block.getFloors();
            for (int i = 0; i < floors.length; i++) {
                System.out.printf("  %-4d  %-15s  %-10d  %-10d  %-10d%n",
                        i,
                        floors[i].getFloorName(),
                        floors[i].getTotalRooms(),
                        floors[i].getOccupiedRooms(),
                        floors[i].getAvailableRooms());
            }
 
            System.out.println();
            System.out.println("  [floor number 0-3] = drill into floor  |  B = back");
            System.out.print("  Choice: ");
            String input = scanner.nextLine().trim();
 
            if (input.equalsIgnoreCase("B")) { running = false; break; }
            try {
                int fn = Integer.parseInt(input);
                if (fn < 0 || fn > 3) throw new InvalidInputException("Floor must be 0–3.");
                drillIntoFloor(block, fn);
            } catch (NumberFormatException e) {
                System.out.println("  [INPUT ERROR] Enter 0–3 or B.");
            } catch (InvalidInputException e) {
                System.out.println("  [INPUT ERROR] " + e.getMessage());
            }
        }
    }
 
    /** Show rooms of one floor; allow drilling into a room */
    private void drillIntoFloor(Block block, int floorNumber) {
        Floor floor = block.getFloor(floorNumber);
        boolean running = true;
 
        while (running) {
            floor.printFloorTable();
            System.out.println();
            System.out.println("  [room label] = view room detail  |  B = back");
            System.out.print("  Choice: ");
            String input = scanner.nextLine().trim();
 
            if (input.equalsIgnoreCase("B")) { running = false; break; }
            Room r = floor.findRoomByLabel(input.toUpperCase());
            if (r == null) {
                System.out.println("  [ERROR] Room \"" + input + "\" not found on this floor.");
            } else {
                r.printDetailCard();
                pause();
            }
        }
    }
 
    // ── 5. View Floor Details ──────────────────────────────────────────────
 
    private void viewFloorDetails() {
        System.out.println("  ════════ FLOOR DETAILS ════════");
        listBlockNames();
        System.out.print("  Enter block name: ");
        String blockName = scanner.nextLine().trim();
        System.out.println("  Floors: 0=Ground  1=Floor 1  2=Floor 2  3=Floor 3");
        try {
            int fn = readInt("  Enter floor number (0–3): ");
            if (fn < 0 || fn > 3) throw new InvalidInputException("Floor must be 0–3.");
            System.out.println();
            allocationService.displayFloorDetail(blockName, fn);
        } catch (InvalidInputException e) {
            System.out.println("  [INPUT ERROR] " + e.getMessage());
        }
        pause();
    }
 
    // ── 6. View Room Details ───────────────────────────────────────────────
 
    public void viewRoomDetails() {
        System.out.println("  ════════ ROOM DETAIL ════════");
        listBlockNames();
        System.out.print("  Enter block name: ");
        String blockName = scanner.nextLine().trim();
        System.out.print("  Enter room label (e.g. G01, 115, 307): ");
        String roomLabel = scanner.nextLine().trim().toUpperCase();
        System.out.println();
        allocationService.displayRoomDetail(blockName, roomLabel);
        pause();
    }
 
    // ── 7. Add New Student and Assign to Room ─────────────────────────────
 
    private void manualAssign() {
        System.out.println("  ════════ ADD STUDENT & ASSIGN TO ROOM ════════");
        System.out.println("  Format: ID,FirstName,LastName,Department,YearOfStudy,Gender(M/F)");
        System.out.println("  Example: S025,Abebe,Kaso,ComputerScience,2,M");
        System.out.println();
        System.out.print("  Enter student details: ");
        String line = scanner.nextLine().trim();
 
        // ── Parse the CSV line ─────────────────────────────────────────────
        String[] parts = line.split(",");
        if (parts.length < 6) {
            System.out.println("  [ERROR] Need all 6 fields: ID,FirstName,LastName,Department,Year,Gender");
            pause();
            return;
        }
 
        String id        = parts[0].trim();
        String firstName = parts[1].trim();
        String lastName  = parts[2].trim();
        String dept      = parts[3].trim();
        String gender    = parts[5].trim().toUpperCase();
        int year;
 
        try {
            year = Integer.parseInt(parts[4].trim());
        } catch (NumberFormatException e) {
            System.out.println("  [ERROR] Year of study must be a number.");
            pause();
            return;
        }
 
        if (!gender.equals("M") && !gender.equals("F")) {
            System.out.println("  [ERROR] Gender must be M or F.");
            pause();
            return;
        }
 
        // ── Check for duplicate ID ─────────────────────────────────────────
        try {
            studentService.findById(id);
            System.out.println("  [ERROR] Student ID " + id + " already exists.");
            pause();
            return;
        } catch (StudentNotFoundException ignored) {}
 
        // ── Create and register the student ───────────────────────────────
        Student student = new Student(id, firstName, lastName, dept, year, gender);
        studentService.addStudent(student);
        System.out.println("  [OK] Student added: " + student.getFullName());
 
        // ── Show eligible blocks ───────────────────────────────────────────
        Block[] blocks = allocationService.getBlocks();
        int bc = allocationService.getBlockCount();
        System.out.println();
        System.out.println("  Eligible blocks:");
        System.out.printf("  %-4s  %-12s  %-24s%n", "No.", "Block", "Department");
        System.out.println("  " + "─".repeat(44));
        int shown = 0;
        for (int i = 0; i < bc; i++) {
            if (blocks[i].getGender().equals(gender) &&
                blocks[i].getDepartment().equalsIgnoreCase(dept)) {
                shown++;
                System.out.printf("  %-4d  %-12s  %-24s%n",
                        shown, blocks[i].getBlockName(), blocks[i].getDepartment());
            }
        }
        if (shown == 0) {
            System.out.println("  No eligible blocks found. Student saved but not assigned.");
            pause();
            return;
        }
 
        // ── Ask for assignment ─────────────────────────────────────────────
        System.out.println();
        System.out.println("  A                 = Auto-assign to first available room");
        System.out.println("  Block RoomLabel   = Assign to specific block and room");
        System.out.println("  Example:  Block M-A G01");
        System.out.print("  Choice: ");
        String choice = scanner.nextLine().trim();
 
        try {
            if (choice.equalsIgnoreCase("A")) {
                allocationService.assignStudent(student);
                System.out.printf("  [OK] %s → Room %s in %s.%n",
                        student.getFullName(),
                        student.getAssignedRoomLabel(),
                        student.getAssignedBlockName());
                fileManager.appendStudentToReport(student.generateReport());
            } else {
                String[] cp = choice.split("\s+");
                if (cp.length < 3)
                    throw new InvalidInputException("Enter A  or  Block RoomLabel (e.g. Block M-A G01)");
                String bName  = cp[0] + " " + cp[1];
                String rLabel = cp[2].toUpperCase();
                allocationService.assignStudentToRoom(student, bName, rLabel);
                System.out.printf("  [OK] %s → Room %s in %s.%n",
                        student.getFullName(),
                        student.getAssignedRoomLabel(),
                        student.getAssignedBlockName());
                fileManager.appendStudentToReport(student.generateReport());
            }
        } catch (GenderMismatchException e) {
            System.out.println("  [GENDER ERROR] " + e.getMessage());
        } catch (DepartmentMismatchException e) {
            System.out.println("  [DEPT ERROR] " + e.getMessage());
        } catch (RoomFullException e) {
            System.out.println("  [ROOM FULL] " + e.getMessage());
        } catch (InvalidInputException e) {
            System.out.println("  [INPUT ERROR] " + e.getMessage());
        }
        pause();
    }
 
    // ── 8. Block Status Report ─────────────────────────────────────────────
 
    private void blockStatusReport() {
        System.out.println("  ════════ BLOCK STATUS REPORT ════════");
        listBlockNames();
        System.out.print("  Enter block name (or ALL for all blocks): ");
        String input = scanner.nextLine().trim();
        System.out.println();
 
        if (input.equalsIgnoreCase("ALL")) {
            Block[] blocks = allocationService.getBlocks();
            int bc = allocationService.getBlockCount();
            for (int i = 0; i < bc; i++) {
                blocks[i].printHeaderCard();
            }
        } else {
            Block b = allocationService.findBlockByName(input);
            if (b == null) System.out.println("  [ERROR] Block not found.");
            else           b.printHeaderCard();
        }
        pause();
    }
 
    // ── 9. Room Availability Search ────────────────────────────────────────
 
    private void searchAvailableRooms() {
        System.out.println("  ════════ ROOM AVAILABILITY SEARCH ════════");
        System.out.println("  Search by:");
        System.out.println("  1. Gender");
        System.out.println("  2. Department");
        System.out.println("  3. Gender + Department");
        System.out.println("  4. Specific block");
        try {
            int choice = readInt("  Choice: ");
            System.out.println();
 
            Block[] blocks = allocationService.getBlocks();
            int bc = allocationService.getBlockCount();
 
            switch (choice) {
                case 1: {
                    System.out.print("  Gender (M/F): ");
                    String g = scanner.nextLine().trim().toUpperCase();
                    printAvailableRoomsFor(blocks, bc, g, null);
                    break;
                }
                case 2: {
                    System.out.print("  Department name: ");
                    String d = scanner.nextLine().trim();
                    printAvailableRoomsFor(blocks, bc, null, d);
                    break;
                }
                case 3: {
                    System.out.print("  Gender (M/F): ");
                    String g = scanner.nextLine().trim().toUpperCase();
                    System.out.print("  Department name: ");
                    String d = scanner.nextLine().trim();
                    printAvailableRoomsFor(blocks, bc, g, d);
                    break;
                }
                case 4: {
                    listBlockNames();
                    System.out.print("  Block name: ");
                    String bn = scanner.nextLine().trim();
                    Block b = allocationService.findBlockByName(bn);
                    if (b == null) { System.out.println("  [ERROR] Block not found."); break; }
                    System.out.printf("  Available rooms in %s:%n", bn);
                    for (Floor f : b.getFloors()) {
                        for (Room r : f.getRooms()) {
                            if (r.isAvailable()) {
                                System.out.printf("  Room %-5s | Floor %-12s%n",
                                        r.getLabel(), f.getFloorName());
                            }
                        }
                    }
                    break;
                }
                default: throw new InvalidInputException("Please enter 1–4.");
            }
        } catch (InvalidInputException e) {
            System.out.println("  [INPUT ERROR] " + e.getMessage());
        }
        pause();
    }
 
    private void printAvailableRoomsFor(Block[] blocks, int bc,
                                         String gender, String dept) {
        int found = 0;
        System.out.printf("  %-12s  %-24s  %-8s  %-6s  %-15s%n",
                "Block", "Department", "Gender", "Room", "Floor");
        System.out.println("  " + "─".repeat(70));
 
        for (int i = 0; i < bc; i++) {
            Block b = blocks[i];
            if (gender != null && !b.getGender().equals(gender)) continue;
            if (dept   != null && !b.getDepartment().equalsIgnoreCase(dept)) continue;
 
            for (Floor f : b.getFloors()) {
                for (Room r : f.getRooms()) {
                    if (!r.isAvailable()) continue;
                    System.out.printf("  %-12s  %-24s  %-8s  %-6s  %-15s%n",
                            b.getBlockName(), b.getDepartment(),
                            b.getGenderLabel(), r.getLabel(),
                            f.getFloorName());
                    found++;
                }
            }
        }
        System.out.println("  " + "─".repeat(70));
        System.out.printf("  %d available room(s) found.%n", found);
    }
 
    // ── Helpers ────────────────────────────────────────────────────────────
 
    private void listBlockNames() {
        Block[] blocks = allocationService.getBlocks();
        int bc = allocationService.getBlockCount();
        if (bc == 0) { System.out.println("  (No blocks created yet)"); return; }
        System.out.print("  Blocks: ");
        for (int i = 0; i < bc; i++) {
            System.out.print(blocks[i].getBlockName());
            if (i < bc - 1) System.out.print("  |  ");
        }
        System.out.println();
    }
 
    private void printMenu() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════════════╗");
        System.out.println("  ║       BLOCK & ROOM MANAGEMENT MENU              ║");
        System.out.println("  ╠══════════════════════════════════════════════════╣");
        System.out.println("  ║   1.  View All Blocks (Overview)                ║");
        System.out.println("  ║   2.  View Block Details                        ║");
        System.out.println("  ║   3.  Browse Male Wing                          ║");
        System.out.println("  ║   4.  Browse Female Wing                        ║");
        System.out.println("  ║   5.  View Floor Details                        ║");
        System.out.println("  ║   6.  View Room Details                         ║");
        System.out.println("  ║   7.  Assign Student to Room (Manual)           ║");
        System.out.println("  ║   8.  Block Status Report                       ║");
        System.out.println("  ║   9.  Room Availability Search                  ║");
        System.out.println("  ║  10.  Back to Main Menu                         ║");
        System.out.println("  ╚══════════════════════════════════════════════════╝");
    }
 
    private int readInt(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Please enter a valid number.");
        }
    }
 
    private void pause() {
        System.out.print("\n  Press ENTER to continue...");
        scanner.nextLine();
    }
}