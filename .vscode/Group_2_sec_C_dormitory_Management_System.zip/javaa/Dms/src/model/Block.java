package model;
 
/**
 * Block — a dormitory building wing.
 *
 * Rules enforced here:
 *  • One block belongs to exactly ONE department.
 *  • One block has exactly ONE gender type (Male or Female).
 *  • One block contains exactly FLOORS_PER_BLOCK (4) floors.
 *  • All floors and rooms are auto-created on construction.
 *
 * Capacity:
 *   4 floors × 18 rooms × 6 students = 432 students per block maximum.
 *
 * Encapsulation: all fields private.
 * Implements Reportable for report generation.
 */
public class Block implements Reportable {
 
    public static final int FLOORS_PER_BLOCK = 4;
 
    // Total capacity constants (derived)
    public static final int ROOMS_PER_BLOCK   = FLOORS_PER_BLOCK * Floor.ROOMS_PER_FLOOR; // 72
    public static final int CAPACITY_PER_BLOCK = ROOMS_PER_BLOCK * Room.MAX_CAPACITY;      // 432
 
    // ── Fields ─────────────────────────────────────────────────────────────
    private String  blockName;      // e.g. "Block A", "Block B"
    private String  department;     // e.g. "ComputerScience"
    private String  gender;         // "M" = Male block, "F" = Female block
 
    private Floor[] floors;         // exactly 4 floors
 
    // ── Constructor ────────────────────────────────────────────────────────
 
    /**
     * @param blockName  human-readable name, e.g. "Block A"
     * @param department department this block belongs to
     * @param gender     "M" for Male block, "F" for Female block
     */
    public Block(String blockName, String department, String gender) {
        this.blockName  = blockName;
        this.department = department;
        this.gender     = gender.toUpperCase();
 
        // Auto-create all 4 floors (each floor auto-creates its 18 rooms)
        this.floors = new Floor[FLOORS_PER_BLOCK];
        for (int i = 0; i < FLOORS_PER_BLOCK; i++) {
            floors[i] = new Floor(i, blockName, department, this.gender);
        }
    }
 
    // ── Getters ────────────────────────────────────────────────────────────
 
    public String  getBlockName()  { return blockName;  }
    public String  getDepartment() { return department; }
    public String  getGender()     { return gender;     }
    public Floor[] getFloors()     { return floors;     }
    public Floor   getFloor(int n) { return (n >= 0 && n < FLOORS_PER_BLOCK) ? floors[n] : null; }
 
    public String  getGenderLabel(){ return gender.equals("M") ? "Male" : "Female"; }
 
    // ── Stats ──────────────────────────────────────────────────────────────
 
    public int getTotalFloors()  { return FLOORS_PER_BLOCK; }
    public int getTotalRooms()   { return ROOMS_PER_BLOCK;  }
 
    public int getOccupiedRooms() {
        int c = 0;
        for (Floor f : floors) c += f.getOccupiedRooms();
        return c;
    }
 
    public int getAvailableRooms() {
        int c = 0;
        for (Floor f : floors) c += f.getAvailableRooms();
        return c;
    }
 
    public int getTotalBeds()    { return CAPACITY_PER_BLOCK; }
 
    public int getOccupiedBeds() {
        int c = 0;
        for (Floor f : floors) c += f.getOccupiedBeds();
        return c;
    }
 
    public int getAvailableBeds() { return getTotalBeds() - getOccupiedBeds(); }
 
    public int getTotalStudents() { return getOccupiedBeds(); }
 
    // ── Room Finders ───────────────────────────────────────────────────────
 
    /**
     * Find the first available room scanning top-down through all floors.
     */
    public Room findAvailableRoom() {
        for (Floor f : floors) {
            Room r = f.findAvailableRoom();
            if (r != null) return r;
        }
        return null;
    }
 
    /**
     * Find a room anywhere in this block by its label.
     */
    public Room findRoomByLabel(String label) {
        for (Floor f : floors) {
            Room r = f.findRoomByLabel(label);
            if (r != null) return r;
        }
        return null;
    }
 
    /**
     * Find a room with available space on a specific floor.
     */
    public Room findAvailableRoomOnFloor(int floorNumber) {
        if (floorNumber < 0 || floorNumber >= FLOORS_PER_BLOCK) return null;
        return floors[floorNumber].findAvailableRoom();
    }
 
    // ── Display ────────────────────────────────────────────────────────────
 
    /**
     * Print the full block detail: header card + all floors + all rooms.
     */
    public void printFullDetail() {
        printHeaderCard();
        for (Floor f : floors) {
            f.printFloorTable();
        }
        System.out.println();
    }
 
    /**
     * Print only the block header / summary card.
     */
    public void printHeaderCard() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════════════════════════════╗");
        System.out.printf ("  ║  BLOCK: %-57s║%n", blockName);
        System.out.println("  ╠══════════════════════════════════════════════════════════════════╣");
        System.out.printf ("  ║  Department  : %-51s║%n", department);
        System.out.printf ("  ║  Gender      : %-51s║%n", getGenderLabel() + " Block");
        System.out.printf ("  ║  Floors      : %-51s║%n", FLOORS_PER_BLOCK
                + "  (Ground + Floor 1 + Floor 2 + Floor 3)");
        System.out.printf ("  ║  Total Rooms : %-51s║%n", getTotalRooms());
        System.out.printf ("  ║  Total Beds  : %-51s║%n", getTotalBeds());
        System.out.println("  ╚══════════════════════════════════════════════════════════════════╝");
    }
 
    /**
     * Print a one-line summary row for use in block listing tables.
     */
    public void printSummaryRow() {
        System.out.printf("  │  %-10s │ %-22s │ %-7s │ %2d floors │ %3d rooms │%n",
                blockName, department, getGenderLabel(),
                FLOORS_PER_BLOCK, getTotalRooms());
    }
 
    // ── Reportable Interface ───────────────────────────────────────────────
 
    @Override
    public String generateReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("=================================================================\n");
        sb.append(String.format("BLOCK REPORT: %s%n", blockName));
        sb.append("=================================================================\n");
        sb.append(String.format("Department      : %s%n", department));
        sb.append(String.format("Gender          : %s%n", getGenderLabel()));
        sb.append(String.format("Total Floors    : %d%n", FLOORS_PER_BLOCK));
        sb.append(String.format("Total Rooms     : %d%n", getTotalRooms()));
        sb.append(String.format("Total Beds      : %d%n", getTotalBeds()));
        sb.append("-----------------------------------------------------------------\n");
        sb.append("ROOMS BY FLOOR:\n");
        for (Floor f : floors) {
            sb.append(String.format("\n  %s:\n", f.getFloorName()));
            for (Room r : f.getRooms()) {
                sb.append("    ").append(r.generateReport());
            }
        }
        return sb.toString();
    }
 
    @Override
    public String getSummary() {
        return String.format("%-10s | %-22s | %-7s",
                blockName, department, getGenderLabel());
    }
}