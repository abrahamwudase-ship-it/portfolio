package model;

/**
 * Interface that any reportable entity must implement.
 * Both Student and Room implement this interface.
 */
public interface Reportable {

    /**
     * Generate a formatted text report of this entity.
     * @return String report content
     */
    String generateReport();

    /**
     * Get a short summary line for list views.
     * @return String summary
     */
    String getSummary();
}
