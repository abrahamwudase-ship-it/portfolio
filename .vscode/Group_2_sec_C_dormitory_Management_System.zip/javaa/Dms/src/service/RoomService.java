package service;

import model.Block;
import model.Room;

/**
 * RoomService — kept as a thin façade over AllocationService.
 * All real logic lives in AllocationService; this class
 * delegates to it so existing callers in MainMenu/ReportMenu
 * don't need rewriting.
 */
public class RoomService {

    private AllocationService allocationService;

    public RoomService(AllocationService allocationService) {
        this.allocationService = allocationService;
    }

    public AllocationService getAllocationService() {
        return allocationService;
    }

    /** Kept so ReportMenu can call generateRoomReport(). */
    public String generateRoomReport() {
        return allocationService.generateFullBlockReport();
    }

    /** Legacy displayAllRooms — delegates to block overview. */
    public void displayAllRooms() {
        allocationService.displayAllBlocks();
    }

    /** Legacy: total room count across all blocks. */
    public int getRoomCount() {
        int total = 0;
        Block[] blocks = allocationService.getBlocks();
        for (int i = 0; i < allocationService.getBlockCount(); i++) {
            total += blocks[i].getTotalRooms();
        }
        return total;
    }
}
