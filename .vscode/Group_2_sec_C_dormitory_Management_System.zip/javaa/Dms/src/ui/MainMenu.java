package ui;
 
import exception.DuplicateStudentException;
import exception.InvalidInputException;
import file.FileManager;
import model.Admin;
import model.Student;
import service.AllocationService;
import service.ComplaintService;
import service.RoomService;
import service.StudentService;
 
import java.util.Scanner;
 
/**
 * MainMenu — top-level console driver.
 *
 * ╔══════════════════════════════════════════════════╗
 * ║              MAIN MENU                          ║
 * ╠══════════════════════════════════════════════════╣
 * ║  1. View All Students                           ║
 * ║  2. Search Student                              ║
 * ║  3. Block & Room Management                     ║
 * ║  4. Allocate Students to Rooms                  ║
 * ║  5. Manage Complaints                           ║
 * ║  6. Generate Reports                            ║
 * ║  7. Exit                                        ║
 * ╚══════════════════════════════════════════════════╝
 */
public class MainMenu {
 
    private StudentService    studentService;
    private AllocationService allocationService;
    private RoomService       roomService;
    private ComplaintService  complaintService;
    private FileManager       fileManager;
    private Scanner           scanner;
    private Admin             admin;
 
    // Sub-menus
    private StudentMenu   studentMenu;
    private RoomMenu      roomMenu;
    private ComplaintMenu complaintMenu;
    private ReportMenu    reportMenu;
 
    public MainMenu() {
        allocationService = new AllocationService();
        studentService    = new StudentService();
        roomService       = new RoomService(allocationService);
        complaintService  = new ComplaintService();
        fileManager       = new FileManager();
        scanner           = new Scanner(System.in);
        admin             = new Admin(
            "A001", "System", "Admin",
            "admin", "admin123",
            "STAFF-01", "Block Office"
        );
    }
 
    // ── Startup ────────────────────────────────────────────────────────────
 
    public void start() {
        printBanner();
        loadData();
 
        studentMenu   = new StudentMenu(studentService, scanner);
        roomMenu      = new RoomMenu(allocationService, studentService, fileManager, scanner);
        complaintMenu = new ComplaintMenu(complaintService, studentService, fileManager, scanner);
        reportMenu    = new ReportMenu(studentService, roomService, complaintService, fileManager, scanner);
 
        runMainLoop();
    }
 
    private void loadData() {
        // 1. Create default department blocks
        allocationService.createDefaultBlocks();
 
        // 2. Load students from file
        Student[] temp = new Student[200];
        int count = 0;
        try {
            count = fileManager.loadStudents(temp, 200);
        } catch (DuplicateStudentException e) {
            System.out.println("  [WARNING] " + e.getMessage());
        }
        studentService.setStudents(temp, count);
 
        // 3. Sort alphabetically
        studentService.sortAlphabetically();
 
        // 4a. Apply pre-defined allocations from allocation_input.txt (if present)
        FileManager.AllocationDirective[] directives =
                new FileManager.AllocationDirective[500];
        int dCount = fileManager.loadAllocationInput(directives, 500);
        if (dCount > 0) {
            allocationService.applyAllocationFile(
                    studentService.getStudents(), studentService.getStudentCount(),
                    directives, dCount);
        }
 
        // 4b. Auto-allocate remaining unassigned students
        allocationService.autoAllocateAll(
                studentService.getStudents(), studentService.getStudentCount());
 
        // 5. Load saved complaints
        model.Complaint[] savedComplaints = new model.Complaint[500];
        int cc = fileManager.loadComplaints(savedComplaints, 500);
        if (cc > 0) {
            complaintService.setComplaints(savedComplaints, cc);
        }
 
    }
 
    // ── Main Loop ──────────────────────────────────────────────────────────
 
    private void runMainLoop() {
        boolean running = true;
        while (running) {
            admin.showMenu();
            try {
                int choice = readInt("  Enter your choice: ");
                System.out.println();
                switch (choice) {
                    case 1: studentMenu.viewAllStudents();  break;
                    case 2: studentMenu.searchStudent();    break;
                    case 3: roomMenu.run();                 break;
                    case 4: allocationMenu();               break;
                    case 5: complaintMenu.run();            break;
                    case 6: reportMenu.run();               break;
                    case 7: viewAdminInfo();                break;
                    case 8: running = false; exitSystem();  break;
                    default: throw new InvalidInputException("Please enter 1–8.");
                }
            } catch (InvalidInputException e) {
                System.out.println("  [INPUT ERROR] " + e.getMessage());
            } catch (Exception e) {
                System.out.println("  [ERROR] " + e.getMessage());
            }
        }
    }
 
    // ── Allocation Sub-menu ────────────────────────────────────────────────
 
    private void allocationMenu() throws InvalidInputException {
        System.out.println("  ╔═══════════════════════════════════════════╗");
        System.out.println("  ║         ALLOCATION MENU                   ║");
        System.out.println("  ╠═══════════════════════════════════════════╣");
        System.out.println("  ║  1. Re-run Auto Allocation                ║");
        System.out.println("  ║  2. Load Allocations from File            ║");
        System.out.println("  ║  3. View Allocation Summary               ║");
        System.out.println("  ║  4. Save Room Assignments to File         ║");
        System.out.println("  ║  5. Back                                  ║");
        System.out.println("  ╚═══════════════════════════════════════════╝");
 
        int choice = readInt("  Enter your choice: ");
        System.out.println();
 
        switch (choice) {
            case 1:
                // Reset blocks and re-allocate (auto only)
                allocationService.createDefaultBlocks();
                studentService.sortAlphabetically();
                // Reset assignment state on all students
                for (int i = 0; i < studentService.getStudentCount(); i++) {
                    Student s = studentService.getStudents()[i];
                    if (s != null) s.setAssignedRoom(null, null);
                }
                allocationService.autoAllocateAll(
                        studentService.getStudents(), studentService.getStudentCount());
                break;
            case 2:
                // Load from allocation_input.txt, then auto-allocate the rest
                allocationService.createDefaultBlocks();
                // Reset assignment state on all students
                for (int i = 0; i < studentService.getStudentCount(); i++) {
                    Student s = studentService.getStudents()[i];
                    if (s != null) s.setAssignedRoom(null, null);
                }
                FileManager.AllocationDirective[] directives =
                        new FileManager.AllocationDirective[500];
                int dCount = fileManager.loadAllocationInput(directives, 500);
                if (dCount > 0) {
                    allocationService.applyAllocationFile(
                            studentService.getStudents(), studentService.getStudentCount(),
                            directives, dCount);
                } else {
                }
                allocationService.autoAllocateAll(
                        studentService.getStudents(), studentService.getStudentCount());
                break;
            case 3:
                allocationService.displayAllBlocks();
                System.out.print("\n  Press ENTER to continue...");
                scanner.nextLine();
                break;
            case 4:
                // Save as a report file
                fileManager.writeReport("room_allocation.txt",
                        allocationService.generateFullBlockReport());
                System.out.print("\n  Press ENTER to continue...");
                scanner.nextLine();
                break;
            case 5:
                break;
            default:
                throw new InvalidInputException("Please enter 1–5.");
        }
    }
 
    // ── Exit ───────────────────────────────────────────────────────────────
 
    private void exitSystem() {
        fileManager.saveComplaints(
                complaintService.getComplaints(), complaintService.getComplaintCount());
        fileManager.writeReport("room_allocation.txt",
                allocationService.generateFullBlockReport());
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════╗");
        System.out.println("  ║  Thank you for using the Dormitory       ║");
        System.out.println("  ║  Management System. Goodbye!             ║");
        System.out.println("  ╚══════════════════════════════════════════╝");
        System.out.println();
    }
 
    // ── Print ──────────────────────────────────────────────────────────────
 
    private void printBanner() {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════════════╗");
        System.out.println("  ║                                                  ║");
        System.out.println("  ║     ARBAMINCH UNIVERSITY DORMITORY               ║");
        System.out.println("  ║          MANAGEMENT SYSTEM                       ║");
        System.out.println("  ║                                                  ║");
        System.out.println("  ╚══════════════════════════════════════════════════╝");
    }
 
    private void viewAdminInfo() {
        admin.displayInfo();
        System.out.print("\n  Press ENTER to continue...");
        scanner.nextLine();
    }
 
    private int readInt(String prompt) throws InvalidInputException {
        System.out.print(prompt);
        try {
            return Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            throw new InvalidInputException("Invalid input — please enter a number.");
        }
    }
}