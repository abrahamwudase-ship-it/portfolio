package file;
 
import model.Complaint;
import model.Student;
import exception.DuplicateStudentException;
 
import java.io.*;
 
/**
 * FileManager handles all file I/O operations for the dormitory system.
 * Uses FileReader, FileWriter, BufferedReader, BufferedWriter (no ArrayList).
 */
public class FileManager {
 
    // ── File paths ─────────────────────────────────────────────────────────
    private static final String STUDENTS_FILE        = "data/students.txt";
    private static final String ROOMS_FILE           = "data/rooms.txt";
    private static final String COMPLAINTS_FILE      = "data/complaints.txt";
    private static final String ALLOCATION_INPUT_FILE = "data/allocation_input.txt";
 
    // ── Student File Operations ────────────────────────────────────────────
 
    /**
     * Load students from students.txt into a fixed-size array.
     * File format: S001,Abebe,Kaso,ComputerScience,2,M
     *
     * @param students   pre-allocated Student array
     * @param maxStudents maximum number of students to load
     * @return actual count of students loaded
     */
    /**
     * Load students from the default data/students.txt.
     */
    public int loadStudents(Student[] students, int maxStudents)
            throws DuplicateStudentException {
        return loadStudents(students, maxStudents, STUDENTS_FILE);
    }
 
    /**
     * Load students from any given file path.
     * File format: ID,FirstName,LastName,Department,YearOfStudy,Gender(M/F)
     * Lines starting with # or blank lines are ignored.
     *
     * @param students    pre-allocated array to fill
     * @param maxStudents maximum students to load
     * @param filePath    path to the txt file (relative or absolute)
     * @return count of students loaded
     */
    public int loadStudents(Student[] students, int maxStudents, String filePath)
            throws DuplicateStudentException {
 
        int count = 0;
        File file = new File(filePath);
 
        if (!file.exists()) {
            if (filePath.equals(STUDENTS_FILE)) {
                    createSampleStudentsFile();
            } else {
                System.out.println("  [ERROR] File not found: " + filePath);
                return 0;
            }
        }
 
 
        BufferedReader br = null;
        FileReader fr = null;
        int lineNumber = 0;
 
        try {
            fr = new FileReader(filePath);
            br = new BufferedReader(fr);
 
            String line;
            while ((line = br.readLine()) != null && count < maxStudents) {
                lineNumber++;
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
 
                String[] parts = line.split(",");
                if (parts.length < 6) {
                    System.out.printf("  [SKIP] Line %d malformed (need 6 fields): %s%n", lineNumber, line);
                    continue;
                }
 
                try {
                    String id        = parts[0].trim();
                    String firstName = parts[1].trim();
                    String lastName  = parts[2].trim();
                    String dept      = parts[3].trim();
                    int    year      = Integer.parseInt(parts[4].trim());
                    String gender    = parts[5].trim().toUpperCase();
 
                    if (!gender.equals("M") && !gender.equals("F")) {
                        System.out.printf("  [SKIP] Line %d: gender must be M or F, got '%s'%n", lineNumber, parts[5].trim());
                        continue;
                    }
 
                    for (int i = 0; i < count; i++) {
                        if (students[i].getId().equalsIgnoreCase(id)) {
                            throw new DuplicateStudentException(
                                "Duplicate student ID on line " + lineNumber + ": " + id, id);
                        }
                    }
 
                    students[count] = new Student(id, firstName, lastName, dept, year, gender);
                    count++;
 
                } catch (NumberFormatException e) {
                    System.out.printf("  [SKIP] Line %d: year of study is not a number: %s%n", lineNumber, line);
                }
            }
 
        } catch (IOException e) {
            System.out.println("  [ERROR] Failed to read file: " + e.getMessage());
        } finally {
            try {
                if (br != null) br.close();
                if (fr != null) fr.close();
            } catch (IOException e) {
                System.out.println("  [ERROR] Failed to close file: " + e.getMessage());
            }
        }
 
        return count;
    }
 
    // ── Allocation Input File Operations ───────────────────────────────────
 
    /**
     * Describes a single directive read from allocation_input.txt.
     * Supports two forms:
     *   StudentID,BlockName,RoomLabel   → specific room
     *   StudentID,BlockName             → any free room in block
     */
    public static class AllocationDirective {
        public final String studentId;
        public final String blockName;
        public final String roomLabel;   // null = pick any available room
 
        public AllocationDirective(String studentId, String blockName, String roomLabel) {
            this.studentId = studentId;
            this.blockName = blockName;
            this.roomLabel = roomLabel;
        }
    }
 
    /**
     * Load allocation directives from data/allocation_input.txt.
     *
     * Supported line formats (# lines and blank lines are ignored):
     *   StudentID,BlockName,RoomLabel
     *   StudentID,BlockName
     *
     * @param directives  pre-allocated array to fill
     * @param maxDirectives maximum entries to load
     * @return count of directives loaded
     */
    public int loadAllocationInput(AllocationDirective[] directives, int maxDirectives) {
        int count = 0;
        File file = new File(ALLOCATION_INPUT_FILE);
 
        if (!file.exists()) {
            createSampleAllocationInputFile();
            return 0;
        }
 
        BufferedReader br = null;
        FileReader fr = null;
        int lineNumber = 0;
 
        try {
            fr = new FileReader(ALLOCATION_INPUT_FILE);
            br = new BufferedReader(fr);
 
            String line;
            while ((line = br.readLine()) != null && count < maxDirectives) {
                lineNumber++;
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
 
                String[] parts = line.split(",");
                if (parts.length < 2) {
                    System.out.printf("  [SKIP] Line %d: need at least StudentID,BlockName — got: %s%n",
                            lineNumber, line);
                    continue;
                }
 
                String studentId = parts[0].trim();
                String blockName = parts[1].trim();
                String roomLabel = (parts.length >= 3) ? parts[2].trim() : null;
 
                if (studentId.isEmpty() || blockName.isEmpty()) {
                    System.out.printf("  [SKIP] Line %d: empty ID or block name.%n", lineNumber);
                    continue;
                }
 
                directives[count++] = new AllocationDirective(studentId, blockName, roomLabel);
            }
 
 
        } catch (IOException e) {
            System.out.println("  [ERROR] Failed to read allocation_input.txt: " + e.getMessage());
        } finally {
            try {
                if (br != null) br.close();
                if (fr != null) fr.close();
            } catch (IOException e) {
                System.out.println("  [ERROR] Failed to close allocation input file: " + e.getMessage());
            }
        }
 
        return count;
    }
 
    /**
     * Create a commented sample allocation_input.txt so users know the format.
     */
    private void createSampleAllocationInputFile() {
        FileWriter fw = null;
        BufferedWriter bw = null;
 
        try {
            ensureDataDir();
            fw = new FileWriter(ALLOCATION_INPUT_FILE);
            bw = new BufferedWriter(fw);
 
            bw.write("# Dormitory Allocation Input File"); bw.newLine();
            bw.write("# Assign specific students to blocks/rooms before auto-allocation runs."); bw.newLine();
            bw.write("#"); bw.newLine();
            bw.write("# Formats:"); bw.newLine();
            bw.write("#   StudentID,BlockName,RoomLabel   -> specific room (e.g. G01, 101, 203)"); bw.newLine();
            bw.write("#   StudentID,BlockName             -> next free room in that block"); bw.newLine();
            bw.write("#"); bw.newLine();
            bw.write("# Gender and Department must match the block — mismatches are reported and skipped."); bw.newLine();
            bw.write("# Students not listed here are handled by auto-allocation afterwards."); bw.newLine();
            bw.write("#"); bw.newLine();
            bw.write("# Example entries (remove # to enable):"); bw.newLine();
            bw.write("# S001,Block M-A,G01"); bw.newLine();
            bw.write("# S002,Block F-B"); bw.newLine();
            bw.newLine();
            bw.flush();
 
        } catch (IOException e) {
            System.out.println("  [ERROR] Failed to create sample allocation file: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("  [ERROR] Failed to close file: " + e.getMessage());
            }
        }
    }
 
    // ── Room File Operations ───────────────────────────────────────────────
 
    /**
     * Save room allocation report to rooms.txt (new block-based format).
     * @param reportContent full text report from AllocationService
     */
    public void saveRoomReport(String reportContent) {
        writeReport("rooms.txt", reportContent);
    }
 
    // ── Complaint File Operations ──────────────────────────────────────────
 
    /**
     * Save all complaints to complaints.txt.
     */
    public void saveComplaints(Complaint[] complaints, int count) {
        FileWriter fw = null;
        BufferedWriter bw = null;
 
        try {
            ensureDataDir();
            fw = new FileWriter(COMPLAINTS_FILE);
            bw = new BufferedWriter(fw);
 
            bw.write("# Complaints - Dormitory Management System");
            bw.newLine();
 
            for (int i = 0; i < count; i++) {
                bw.write(complaints[i].toCSV());
                bw.newLine();
            }
 
            bw.flush();
 
        } catch (IOException e) {
            System.out.println("[ERROR] Failed to save complaints: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("[ERROR] Failed to close complaints file: " + e.getMessage());
            }
        }
    }
 
    /**
     * Load complaints from complaints.txt.
     */
    public int loadComplaints(Complaint[] complaints, int maxComplaints) {
        int count = 0;
        File file = new File(COMPLAINTS_FILE);
        if (!file.exists()) return 0;
 
        FileReader fr = null;
        BufferedReader br = null;
 
        try {
            fr = new FileReader(COMPLAINTS_FILE);
            br = new BufferedReader(fr);
 
            String line;
            while ((line = br.readLine()) != null && count < maxComplaints) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;
 
                Complaint c = Complaint.fromCSV(line);
                if (c != null) {
                    complaints[count++] = c;
                }
            }
 
        } catch (IOException e) {
            System.out.println("[ERROR] Failed to load complaints: " + e.getMessage());
        } finally {
            try {
                if (br != null) br.close();
                if (fr != null) fr.close();
            } catch (IOException e) {
                System.out.println("[ERROR] Failed to close complaints file: " + e.getMessage());
            }
        }
 
        return count;
    }
 
    // ── Report File Operations ─────────────────────────────────────────────

    /**
     * Append a single student's report entry to student_report.txt.
     * Creates the file with a header if it does not yet exist.
     *
     * @param studentEntry the formatted report block for one student
     *                     (produced by Student.generateReport())
     */
    public void appendStudentToReport(String studentEntry) {
        FileWriter fw = null;
        BufferedWriter bw = null;

        try {
            ensureDataDir();
            File reportFile = new File("data/student_report.txt");
            boolean isNew = !reportFile.exists() || reportFile.length() == 0;

            fw = new FileWriter(reportFile, true);   // append = true
            bw = new BufferedWriter(fw);

            if (isNew) {
                bw.write("================================================");
                bw.newLine();
                bw.write("       STUDENT REPORT - DORMITORY SYSTEM        ");
                bw.newLine();
                bw.write("================================================");
                bw.newLine();
                bw.newLine();
            }

            bw.write(studentEntry);
            bw.write("----------------------------------");
            bw.newLine();
            bw.flush();

            System.out.println("  [OK] Student record appended to student_report.txt");

        } catch (IOException e) {
            System.out.println("  [ERROR] Failed to update student_report.txt: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("  [ERROR] Failed to close student_report.txt: " + e.getMessage());
            }
        }
    }

    /**
     * Write a report string to a given output file.
     */
    public void writeReport(String filename, String content) {
        FileWriter fw = null;
        BufferedWriter bw = null;
 
        try {
            ensureDataDir();
            fw = new FileWriter("data/" + filename);
            bw = new BufferedWriter(fw);
            bw.write(content);
            bw.flush();
 
        } catch (IOException e) {
            System.out.println("[ERROR] Failed to write report: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("[ERROR] Failed to close report file: " + e.getMessage());
            }
        }
    }
 
    // ── Helpers ────────────────────────────────────────────────────────────
 
    private void ensureDataDir() {
        File dir = new File("data");
        if (!dir.exists()) dir.mkdirs();
    }
 
    /**
     * Create a sample students.txt for first-time use.
     */
    private void createSampleStudentsFile() {
        FileWriter fw = null;
        BufferedWriter bw = null;
 
        try {
            ensureDataDir();
            fw = new FileWriter(STUDENTS_FILE);
            bw = new BufferedWriter(fw);
 
            bw.write("# Dormitory Management System - Students File");
            bw.newLine();
            bw.write("# Format: ID,FirstName,LastName,Department,YearOfStudy,Gender(M/F)");
            bw.newLine();
            bw.write("S001,Abebe,Kaso,ComputerScience,2,M"); bw.newLine();
            bw.write("S002,Hana,Tesfaye,SoftwareEngineering,1,F"); bw.newLine();
            bw.write("S003,Mike,Daniel,IT,3,M"); bw.newLine();
            bw.write("S004,Chaltu,Gemechu,ComputerScience,1,F"); bw.newLine();
            bw.write("S005,Dawit,Bekele,ElectricalEngineering,2,M"); bw.newLine();
            bw.write("S006,Eyerusalem,Hailu,Mathematics,3,F"); bw.newLine();
            bw.write("S007,Fekadu,Alemu,Physics,2,M"); bw.newLine();
            bw.write("S008,Genet,Worku,Chemistry,1,F"); bw.newLine();
            bw.write("S009,Haile,Selassie,IT,4,M"); bw.newLine();
            bw.write("S010,Iman,Ibrahim,SoftwareEngineering,2,F"); bw.newLine();
            bw.write("S011,Jember,Tadesse,ComputerScience,3,F"); bw.newLine();
            bw.write("S012,Kebede,Mamo,ElectricalEngineering,1,M"); bw.newLine();
            bw.write("S013,Liya,Solomon,Accounting,2,F"); bw.newLine();
            bw.write("S014,Mohammed,Idris,Economics,3,M"); bw.newLine();
            bw.write("S015,Nardos,Getachew,ComputerScience,1,F"); bw.newLine();
            bw.write("S016,Omar,Farah,IT,2,M"); bw.newLine();
            bw.write("S017,Rahel,Tsegaye,Mathematics,4,F"); bw.newLine();
            bw.write("S018,Samuel,Girma,Physics,1,M"); bw.newLine();
            bw.write("S019,Tigist,Alemu,SoftwareEngineering,2,F"); bw.newLine();
            bw.write("S020,Yonas,Habtamu,ComputerScience,3,M"); bw.newLine();
            bw.write("S021,Zerihun,Tadesse,ElectricalEngineering,1,M"); bw.newLine();
            bw.write("S022,Almaz,Bekele,Chemistry,2,F"); bw.newLine();
            bw.write("S023,Berhane,Woldemariam,IT,3,M"); bw.newLine();
            bw.write("S024,Desta,Mekonnen,Economics,1,F"); bw.newLine();
 
            bw.flush();
 
        } catch (IOException e) {
            System.out.println("[ERROR] Failed to create sample file: " + e.getMessage());
        } finally {
            try {
                if (bw != null) bw.close();
                if (fw != null) fw.close();
            } catch (IOException e) {
                System.out.println("[ERROR] Failed to close sample file: " + e.getMessage());
            }
        }
    }
}