package exception;

/**
 * Thrown when a student's gender does not match the block's gender type.
 * A male student cannot be assigned to a Female block, and vice-versa.
 */
public class GenderMismatchException extends Exception {

    private String studentGender;
    private String blockGender;
    private String blockName;

    public GenderMismatchException(String studentGender, String blockGender, String blockName) {
        super("Gender mismatch: A " + (studentGender.equals("M") ? "Male" : "Female")
            + " student cannot be assigned to the "
            + (blockGender.equals("M") ? "Male" : "Female")
            + " block \"" + blockName + "\".");
        this.studentGender = studentGender;
        this.blockGender   = blockGender;
        this.blockName     = blockName;
    }

    public String getStudentGender() { return studentGender; }
    public String getBlockGender()   { return blockGender;   }
    public String getBlockName()     { return blockName;     }
}
