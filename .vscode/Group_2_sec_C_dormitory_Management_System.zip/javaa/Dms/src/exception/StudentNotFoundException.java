package exception;

/**
 * Thrown when a student cannot be found in the system.
 */
public class StudentNotFoundException extends Exception {

    private String searchKey;

    public StudentNotFoundException(String message) {
        super(message);
    }

    public StudentNotFoundException(String message, String searchKey) {
        super(message);
        this.searchKey = searchKey;
    }

    public String getSearchKey() {
        return searchKey;
    }
}
