package model;

/**
 * Abstract base class representing a Person in the dormitory system.
 * All persons (Students, Admins) extend this class.
 */
public abstract class Person {

    private String id;
    private String firstName;
    private String lastName;

    public Person(String id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    // Getters and Setters (Encapsulation)
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public String getFullName() {
        return firstName + " " + lastName;
    }

    // Abstract method — must be implemented by subclasses (Polymorphism)
    public abstract void displayInfo();

    // Abstract method for role identification
    public abstract String getRole();
}
