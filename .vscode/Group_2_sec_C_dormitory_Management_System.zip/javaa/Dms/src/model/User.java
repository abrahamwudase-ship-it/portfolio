package model;

/**
 * Abstract User class that extends Person.
 * Represents a system user (Student or Admin).
 * Demonstrates multi-level inheritance.
 */
public abstract class User extends Person {

    private String username;
    private String password;

    public User(String id, String firstName, String lastName,
                String username, String password) {
        super(id, firstName, lastName);
        this.username = username;
        this.password = password;
    }

    // Getters and Setters
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    /**
     * Abstract menu method — each user type shows its own menu (Polymorphism).
     */
    public abstract void showMenu();

    /**
     * Authenticate user by checking password.
     */
    public boolean authenticate(String inputPassword) {
        return this.password.equals(inputPassword);
    }
}
