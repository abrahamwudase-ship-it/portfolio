package exception;

/**
 * Thrown when a student's department does not match the block's department.
 */
public class DepartmentMismatchException extends Exception {

    private String studentDept;
    private String blockDept;
    private String blockName;

    public DepartmentMismatchException(String studentDept, String blockDept, String blockName) {
        super("Department mismatch: Student from \"" + studentDept
            + "\" cannot be placed in block \"" + blockName
            + "\" which belongs to \"" + blockDept + "\".");
        this.studentDept = studentDept;
        this.blockDept   = blockDept;
        this.blockName   = blockName;
    }

    public String getStudentDept() { return studentDept; }
    public String getBlockDept()   { return blockDept;   }
    public String getBlockName()   { return blockName;   }
}
