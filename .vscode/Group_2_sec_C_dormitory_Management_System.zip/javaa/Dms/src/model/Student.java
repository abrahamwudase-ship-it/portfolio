package model;

/**
 * Student — extends User, implements Reportable.
 * Tracks the assigned room label (e.g. "G05", "201") and block name.
 */
public class Student extends User implements Reportable {

    private String department;
    private int    yearOfStudy;
    private String gender;           // "M" or "F"

    // Room assignment (label-based, not integer)
    private String assignedRoomLabel;  // null = unassigned
    private String assignedBlockName;  // null = unassigned

    private boolean hasComplaint;

    // ── Constructor ────────────────────────────────────────────────────────

    public Student(String id, String firstName, String lastName,
                   String department, int yearOfStudy, String gender) {
        super(id, firstName, lastName, firstName.toLowerCase(), id);
        this.department       = department;
        this.yearOfStudy      = yearOfStudy;
        this.gender           = gender;
        this.assignedRoomLabel = null;
        this.assignedBlockName = null;
        this.hasComplaint      = false;
    }

    // ── Getters & Setters ──────────────────────────────────────────────────

    public String getDepartment()       { return department; }
    public void   setDepartment(String d) { this.department = d; }

    public int    getYearOfStudy()      { return yearOfStudy; }
    public void   setYearOfStudy(int y) { this.yearOfStudy = y; }

    public String getGender()           { return gender; }
    public void   setGender(String g)   { this.gender = g; }

    public String getAssignedRoomLabel()  { return assignedRoomLabel; }
    public String getAssignedBlockName()  { return assignedBlockName; }

    public boolean isAssigned() {
        return assignedRoomLabel != null && !assignedRoomLabel.isEmpty();
    }

    /**
     * Called by Room.assignStudent() to stamp this student with their location.
     */
    public void setAssignedRoom(String roomLabel, String blockName) {
        this.assignedRoomLabel = roomLabel;
        this.assignedBlockName = blockName;
    }

    /** Legacy compatibility for old code that used int room numbers */
    public void setAssignedRoomNumber(int n) {
        this.assignedRoomLabel = String.valueOf(n);
    }
    public int getAssignedRoomNumber() {
        try { return Integer.parseInt(assignedRoomLabel); }
        catch (Exception e) { return -1; }
    }

    public boolean isHasComplaint()           { return hasComplaint; }
    public void    setHasComplaint(boolean b) { this.hasComplaint = b; }

    // ── Overridden Abstract Methods ────────────────────────────────────────

    @Override
    public void displayInfo() {
        System.out.println("  ┌────────────────────────────────────────────┐");
        System.out.println("  │           STUDENT INFORMATION              │");
        System.out.println("  ├────────────────────────────────────────────┤");
        System.out.printf ("  │  ID         : %-28s │%n", getId());
        System.out.printf ("  │  Name       : %-28s │%n", getFullName());
        System.out.printf ("  │  Department : %-28s │%n", department);
        System.out.printf ("  │  Year       : %-28s │%n", yearOfStudy);
        System.out.printf ("  │  Gender     : %-28s │%n", gender.equals("M") ? "Male" : "Female");
        System.out.printf ("  │  Block      : %-28s │%n",
                assignedBlockName != null ? assignedBlockName : "Not Assigned");
        System.out.printf ("  │  Room       : %-28s │%n",
                assignedRoomLabel != null ? assignedRoomLabel : "Not Assigned");
        System.out.println("  └────────────────────────────────────────────┘");
    }

    @Override public String getRole()   { return "Student"; }

    @Override
    public void showMenu() {
        System.out.println("  ┌─────────────────────────────────────────┐");
        System.out.println("  │            STUDENT MENU                 │");
        System.out.println("  ├─────────────────────────────────────────┤");
        System.out.println("  │  1. View My Information                 │");
        System.out.println("  │  2. View My Room                        │");
        System.out.println("  │  3. Submit Complaint                    │");
        System.out.println("  │  4. View My Complaint Status            │");
        System.out.println("  │  5. Logout                              │");
        System.out.println("  └─────────────────────────────────────────┘");
    }

    // ── Reportable ─────────────────────────────────────────────────────────

    @Override
    public String generateReport() {
        return String.format(
            "STUDENT REPORT\n" +
            "==============\n" +
            "ID         : %s\n" +
            "Name       : %s\n" +
            "Department : %s\n" +
            "Year       : %d\n" +
            "Gender     : %s\n" +
            "Block      : %s\n" +
            "Room       : %s\n",
            getId(), getFullName(), department, yearOfStudy,
            gender.equals("M") ? "Male" : "Female",
            assignedBlockName != null ? assignedBlockName : "Not Assigned",
            assignedRoomLabel != null ? assignedRoomLabel : "Not Assigned"
        );
    }

    @Override
    public String getSummary() {
        return String.format("%-6s | %-22s | %-22s | Yr%d | %s | %-8s | %s",
                getId(), getFullName(), department, yearOfStudy,
                gender.equals("M") ? "M" : "F",
                assignedBlockName != null ? assignedBlockName : "N/A",
                assignedRoomLabel != null ? assignedRoomLabel : "N/A");
    }

    public String toCSV() {
        return getId() + "," + getFirstName() + "," + getLastName() + ","
                + department + "," + yearOfStudy + "," + gender;
    }
}
