package ui;
import ui.MainMenu;

/**
 * Main — application entry point.
 *
 * Compile from DormitorySystem/src/:
 *   javac -d ../out model/*.java exception/*.java file/*.java service/*.java ui/*.java Main.java
 *
 * Run from DormitorySystem/out/:
 *   java Main
 */
public class Main {
    public static void main(String[] args) {
        MainMenu menu = new MainMenu();
        menu.start();
    }
}