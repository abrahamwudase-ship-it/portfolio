package service;
 
import exception.DepartmentMismatchException;
import exception.GenderMismatchException;
import exception.RoomFullException;
import file.FileManager;
import model.Block;
import model.Floor;
import model.Room;
import model.Student;
 
/**
 * AllocationService — the central engine for block and room management.
 *
 * Responsibilities:
 *  1. Hold and manage all Block objects (fixed array, max 50 blocks).
 *  2. Create blocks per spec: name + department + gender.
 *  3. Auto-allocate students to the correct block (gender + dept match).
 *  4. Enforce gender-segregation and department rules with exceptions.
 *  5. Provide all query and display operations.
 *
 * Structure guaranteed by spec:
 *   Each block → 4 floors (Ground, 1, 2, 3)
 *   Each floor → 18 rooms
 *   Each room  → max 6 students
 */
public class AllocationService {
 
    private static final int MAX_BLOCKS = 50;
 
    private Block[] blocks;
    private int     blockCount;
 
    public AllocationService() {
        blocks     = new Block[MAX_BLOCKS];
        blockCount = 0;
    }
 
    // ── Block Management ───────────────────────────────────────────────────
 
    /**
     * Create and register a new block.
     *
     * @param blockName  e.g. "Block A"
     * @param department e.g. "ComputerScience"
     * @param gender     "M" or "F"
     * @return the new Block
     * @throws IllegalArgumentException if name already exists or array full
     */
    public Block createBlock(String blockName, String department, String gender) {
        if (blockCount >= MAX_BLOCKS)
            throw new IllegalArgumentException("Maximum number of blocks reached.");
        if (findBlockByName(blockName) != null)
            throw new IllegalArgumentException("Block \"" + blockName + "\" already exists.");
        if (!gender.equalsIgnoreCase("M") && !gender.equalsIgnoreCase("F"))
            throw new IllegalArgumentException("Gender must be M or F.");
 
        Block b = new Block(blockName, department, gender.toUpperCase());
        blocks[blockCount++] = b;
        return b;
    }
 
    /** Find a block by exact name (case-insensitive). Returns null if not found. */
    public Block findBlockByName(String name) {
        for (int i = 0; i < blockCount; i++) {
            if (blocks[i].getBlockName().equalsIgnoreCase(name)) return blocks[i];
        }
        return null;
    }
 
    /** Find the correct block for a student (matching gender + department). */
    public Block findBlockForStudent(Student s) {
        for (int i = 0; i < blockCount; i++) {
            Block b = blocks[i];
            if (b.getGender().equals(s.getGender()) &&
                b.getDepartment().equalsIgnoreCase(s.getDepartment())) {
                return b;
            }
        }
        return null;
    }
 
    public Block[] getBlocks()  { return blocks;     }
    public int     getBlockCount() { return blockCount; }
 
    // ── Student Assignment ─────────────────────────────────────────────────
 
    /**
     * Assign a student to the correct block automatically.
     *
     * Rules enforced:
     *  a) Block must exist for this gender + department combination.
     *  b) Gender must match (throws GenderMismatchException).
     *  c) Department must match (throws DepartmentMismatchException).
     *  d) Room must have capacity (throws RoomFullException).
     *
     * @throws GenderMismatchException     if gender doesn't match
     * @throws DepartmentMismatchException if dept doesn't match
     * @throws RoomFullException           if entire block is full
     */
    public void assignStudent(Student student)
            throws GenderMismatchException, DepartmentMismatchException, RoomFullException {
 
        Block block = findBlockForStudent(student);
 
        if (block == null) {
            throw new DepartmentMismatchException(
                student.getDepartment(), "(no block)", "(none created)");
        }
 
        // Verify gender (should always pass here, but explicit guard)
        if (!block.getGender().equals(student.getGender())) {
            throw new GenderMismatchException(
                student.getGender(), block.getGender(), block.getBlockName());
        }
 
        // Find available room
        Room room = block.findAvailableRoom();
        if (room == null) {
            throw new RoomFullException("All rooms in " + block.getBlockName() + " are full!");
        }
 
        room.assignStudent(student);
    }
 
    /**
     * Assign a student to a SPECIFIC block by name.
     * Validates gender and department before assignment.
     */
    public void assignStudentToBlock(Student student, String blockName)
            throws GenderMismatchException, DepartmentMismatchException, RoomFullException {
 
        Block block = findBlockByName(blockName);
        if (block == null)
            throw new IllegalArgumentException("Block \"" + blockName + "\" does not exist.");
 
        // Enforce gender rule
        if (!block.getGender().equals(student.getGender())) {
            throw new GenderMismatchException(
                student.getGender(), block.getGender(), blockName);
        }
 
        // Enforce department rule
        if (!block.getDepartment().equalsIgnoreCase(student.getDepartment())) {
            throw new DepartmentMismatchException(
                student.getDepartment(), block.getDepartment(), blockName);
        }
 
        Room room = block.findAvailableRoom();
        if (room == null)
            throw new RoomFullException("All rooms in " + blockName + " are full!");
 
        room.assignStudent(student);
    }
 
    /**
     * Assign a student to a SPECIFIC room label within a block.
     * Validates gender and department.
     */
    public void assignStudentToRoom(Student student, String blockName, String roomLabel)
            throws GenderMismatchException, DepartmentMismatchException, RoomFullException {
 
        Block block = findBlockByName(blockName);
        if (block == null)
            throw new IllegalArgumentException("Block \"" + blockName + "\" does not exist.");
 
        if (!block.getGender().equals(student.getGender()))
            throw new GenderMismatchException(
                student.getGender(), block.getGender(), blockName);
 
        if (!block.getDepartment().equalsIgnoreCase(student.getDepartment()))
            throw new DepartmentMismatchException(
                student.getDepartment(), block.getDepartment(), blockName);
 
        Room room = block.findRoomByLabel(roomLabel);
        if (room == null)
            throw new IllegalArgumentException(
                "Room \"" + roomLabel + "\" not found in " + blockName);
 
        room.assignStudent(student);
    }
 
    /**
     * Apply pre-defined allocations from allocation_input.txt directives.
     *
     * Each directive is processed in order:
     *  - Student must exist in the students array.
     *  - Block must exist and gender/department must match.
     *  - If a RoomLabel is given, assigns to that specific room.
     *  - If no RoomLabel, assigns to the next available room in the block.
     *  - Already-assigned students are skipped with a warning.
     *
     * @param students       the full student array from StudentService
     * @param studentCount   how many students are active
     * @param directives     array of AllocationDirective from FileManager
     * @param directiveCount how many directives were loaded
     * @return number of students successfully placed by this method
     */
    public int applyAllocationFile(
            Student[] students, int studentCount,
            FileManager.AllocationDirective[] directives, int directiveCount) {
 
        int placed = 0, skipped = 0;
 
 
        for (int d = 0; d < directiveCount; d++) {
            FileManager.AllocationDirective dir = directives[d];
 
            // Find the student
            Student student = null;
            for (int i = 0; i < studentCount; i++) {
                if (students[i] != null && students[i].getId().equalsIgnoreCase(dir.studentId)) {
                    student = students[i];
                    break;
                }
            }
 
            if (student == null) {
                System.out.printf("  [SKIP] ID %-6s not found in student list.%n", dir.studentId);
                skipped++;
                continue;
            }
 
            if (student.isAssigned()) {
                System.out.printf("  [SKIP] %-22s already assigned to %s / %s%n",
                        student.getFullName(), student.getAssignedBlockName(),
                        student.getAssignedRoomLabel());
                skipped++;
                continue;
            }
 
            try {
                if (dir.roomLabel != null && !dir.roomLabel.isEmpty()) {
                    assignStudentToRoom(student, dir.blockName, dir.roomLabel);
                } else {
                    assignStudentToBlock(student, dir.blockName);
                }
                placed++;
 
            } catch (GenderMismatchException e) {
                System.out.printf("  [FAIL-GENDER]  %-22s → %s: gender mismatch (%s vs %s)%n",
                        student.getFullName(), dir.blockName,
                        student.getGender(), e.getMessage());
                skipped++;
            } catch (DepartmentMismatchException e) {
                System.out.printf("  [FAIL-DEPT]    %-22s → %s: dept mismatch (%s)%n",
                        student.getFullName(), dir.blockName, student.getDepartment());
                skipped++;
            } catch (RoomFullException e) {
                System.out.printf("  [FAIL-FULL]    %-22s → %s is full.%n",
                        student.getFullName(), dir.blockName);
                skipped++;
            } catch (IllegalArgumentException e) {
                System.out.printf("  [FAIL-ERROR]   %-22s → %s: %s%n",
                        student.getFullName(), dir.blockName, e.getMessage());
                skipped++;
            }
        }
 
        return placed;
    }
 
    /**
     * Auto-allocate ALL students (sorted alphabetically) to their blocks.
     * Students with no matching block are reported but not assigned.
     */
    public void autoAllocateAll(Student[] students, int count) {
        int assigned = 0, skipped = 0;
 
        for (int i = 0; i < count; i++) {
            Student s = students[i];
            if (s.isAssigned()) { assigned++; continue; } // already placed
 
            try {
                assignStudent(s);
                assigned++;
            } catch (GenderMismatchException e) {
                System.out.printf("  [SKIP - GENDER]   %s → %s%n",
                        s.getFullName(), e.getMessage());
                skipped++;
            } catch (DepartmentMismatchException e) {
                System.out.printf("  [SKIP - NO BLOCK] %s (%s / %s) → no matching block%n",
                        s.getFullName(), s.getDepartment(),
                        s.getGender().equals("M") ? "Male" : "Female");
                skipped++;
            } catch (RoomFullException e) {
                System.out.printf("  [SKIP - FULL]     %s → %s%n",
                        s.getFullName(), e.getMessage());
                skipped++;
            }
        }
 
    }
 
    // ── Block Setup — Default Ethiopian University Blocks ─────────────────
 
    /**
     * Create the default set of blocks matching the departments in students.txt.
     * Called automatically at startup if no blocks exist.
     *
     * Male blocks:   M-CS, M-SE, M-IT, M-EE, M-PH, M-EC
     * Female blocks: F-CS, F-SE, F-IT, F-MA, F-CH, F-EC, F-AC
     */
    public void createDefaultBlocks() {
        blockCount = 0; // reset
 
        // ── Male Blocks ────────────────────────────────────────────────────
        createBlock("Block M-A",  "ComputerScience",        "M");
        createBlock("Block M-B",  "SoftwareEngineering",    "M");
        createBlock("Block M-C",  "IT",                     "M");
        createBlock("Block M-D",  "ElectricalEngineering",  "M");
        createBlock("Block M-E",  "Physics",                "M");
        createBlock("Block M-F",  "Economics",              "M");
        createBlock("Block M-G",  "Mathematics",            "M");
        createBlock("Block M-H",  "Chemistry",              "M");
        createBlock("Block M-I",  "Accounting",             "M");
 
        // ── Female Blocks ──────────────────────────────────────────────────
        createBlock("Block F-A",  "ComputerScience",        "F");
        createBlock("Block F-B",  "SoftwareEngineering",    "F");
        createBlock("Block F-C",  "IT",                     "F");
        createBlock("Block F-D",  "ElectricalEngineering",  "F");
        createBlock("Block F-E",  "Physics",                "F");
        createBlock("Block F-F",  "Economics",              "F");
        createBlock("Block F-G",  "Mathematics",            "F");
        createBlock("Block F-H",  "Chemistry",              "F");
        createBlock("Block F-I",  "Accounting",             "F");
 
    }
 
    // ── Display / Reports ──────────────────────────────────────────────────
 
    /**
     * Print the full block listing table (one row per block).
     */
    public void displayAllBlocks() {
        if (blockCount == 0) {
            System.out.println("  No blocks created yet.");
            return;
        }
 
        displayBlocksForGender("M", "MALE WING — DEPARTMENT BLOCKS");
        displayBlocksForGender("F", "FEMALE WING — DEPARTMENT BLOCKS");
 
        // System totals
        int totalBeds = 0, totalOccupied = 0;
        for (int i = 0; i < blockCount; i++) {
            totalBeds     += blocks[i].getTotalBeds();
            totalOccupied += blocks[i].getOccupiedBeds();
        }
        System.out.println();
        System.out.printf("  SYSTEM TOTAL: %d blocks | %d total beds%n",
                blockCount, totalBeds);
    }
 
    private void displayBlocksForGender(String gender, String wingTitle) {
        System.out.println();
        System.out.println("  ╔══════════════════════════════════════════════════════════════════════════════╗");
        System.out.printf ("  ║  %-78s║%n", "  " + wingTitle);
        System.out.println("  ╠══════════╦════════════════════════╦═════════╦══════════╦═══════════╣");
        System.out.println("  ║  Block   ║  Department            ║  Gender ║  Floors  ║  Rooms    ║");
        System.out.println("  ╠══════════╬════════════════════════╬═════════╬══════════╬═══════════╣");
 
        boolean any = false;
        for (int i = 0; i < blockCount; i++) {
            if (!blocks[i].getGender().equals(gender)) continue;
            blocks[i].printSummaryRow();
            any = true;
        }
 
        if (!any) {
            System.out.printf("  │  %-76s │%n", "(No " + (gender.equals("M") ? "male" : "female") + " blocks)");
        }
        System.out.println("  ╚══════════╩════════════════════════╩═════════╩══════════╩═══════════╝");
    }
 
    /**
     * Print full detail (all floors + rooms) of ONE block.
     */
    public void displayBlockDetail(String blockName) {
        Block b = findBlockByName(blockName);
        if (b == null) {
            System.out.println("  [ERROR] Block \"" + blockName + "\" not found.");
            return;
        }
        b.printFullDetail();
    }
 
    /**
     * Print status of a specific floor within a block.
     */
    public void displayFloorDetail(String blockName, int floorNumber) {
        Block b = findBlockByName(blockName);
        if (b == null) { System.out.println("  [ERROR] Block not found."); return; }
        Floor f = b.getFloor(floorNumber);
        if (f == null) { System.out.println("  [ERROR] Floor " + floorNumber + " not found."); return; }
        b.printHeaderCard();
        f.printFloorTable();
    }
 
    /**
     * Print detail card of a specific room.
     */
    public void displayRoomDetail(String blockName, String roomLabel) {
        Block b = findBlockByName(blockName);
        if (b == null) { System.out.println("  [ERROR] Block not found."); return; }
        Room r = b.findRoomByLabel(roomLabel);
        if (r == null) {
            System.out.println("  [ERROR] Room \"" + roomLabel + "\" not found in " + blockName);
            return;
        }
        r.printDetailCard();
    }
 
    /**
     * Generate a full text report of all blocks.
     */
    public String generateFullBlockReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("=================================================================\n");
        sb.append("       BLOCK & ROOM REPORT — DORMITORY MANAGEMENT SYSTEM\n");
        sb.append("=================================================================\n\n");
        sb.append(String.format("Total Blocks : %d%n", blockCount));
 
        int totalBeds = 0, occ = 0;
        for (int i = 0; i < blockCount; i++) {
            totalBeds += blocks[i].getTotalBeds();
            occ       += blocks[i].getOccupiedBeds();
        }
        sb.append(String.format("Total Beds   : %d%n", totalBeds));
 
 
        for (int i = 0; i < blockCount; i++) {
            sb.append(blocks[i].generateReport()).append("\n");
        }
        return sb.toString();
    }
 
    /**
     * Get unique department names that have blocks assigned (for dynamic lookup).
     */
    public String[] getRegisteredDepartments(int[] outCount) {
        String[] depts = new String[MAX_BLOCKS];
        int dc = 0;
        for (int i = 0; i < blockCount; i++) {
            String d = blocks[i].getDepartment();
            boolean found = false;
            for (int j = 0; j < dc; j++) if (depts[j].equalsIgnoreCase(d)) { found = true; break; }
            if (!found) depts[dc++] = d;
        }
        outCount[0] = dc;
        return depts;
    }
}