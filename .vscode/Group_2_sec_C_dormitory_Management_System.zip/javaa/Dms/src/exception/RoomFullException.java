package exception;

/**
 * Thrown when a Room has reached its maximum student capacity.
 */
public class RoomFullException extends Exception {

    private String roomLabel;
    private int    capacity;

    public RoomFullException(String message) {
        super(message);
    }

    public RoomFullException(String roomLabel, int capacity) {
        super("Room " + roomLabel + " is full! Maximum capacity is " + capacity + " students.");
        this.roomLabel = roomLabel;
        this.capacity  = capacity;
    }

    public String getRoomLabel() { return roomLabel; }
    public int    getCapacity()  { return capacity;  }
}
