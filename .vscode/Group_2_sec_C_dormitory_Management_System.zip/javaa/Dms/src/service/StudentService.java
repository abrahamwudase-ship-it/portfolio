package service;
 
import exception.DuplicateStudentException;
import exception.StudentNotFoundException;
import model.Student;
 
/**
 * StudentService handles all student-related business logic.
 * Uses a fixed-size array to store students (no ArrayList).
 */
public class StudentService {
 
    private static final int MAX_STUDENTS = 200;
    private Student[] students;
    private int studentCount;
 
    public StudentService() {
        students = new Student[MAX_STUDENTS];
        studentCount = 0;
    }
 
    // ── Load / Init ────────────────────────────────────────────────────────
 
    /**
     * Called after FileManager loads students into a temporary array.
     * Copies students into this service's internal array.
     */
    public void setStudents(Student[] loadedStudents, int count) {
        this.studentCount = count;
        for (int i = 0; i < count; i++) {
            students[i] = loadedStudents[i];
        }
    }
 
    public Student[] getStudents() { return students; }
    public int getStudentCount()   { return studentCount; }
 
    /**
     * Add a single new student to the array (used by manual entry).
     */
    public void addStudent(Student student) {
        if (studentCount < students.length) {
            students[studentCount++] = student;
        }
    }
 
    // ── Sort ───────────────────────────────────────────────────────────────
 
    /**
     * Sort students alphabetically by first name (Bubble Sort).
     * Required by specification.
     */
    public void sortAlphabetically() {
        for (int i = 0; i < studentCount - 1; i++) {
            for (int j = 0; j < studentCount - 1 - i; j++) {
                String name1 = students[j].getFirstName().toLowerCase();
                String name2 = students[j + 1].getFirstName().toLowerCase();
                if (name1.compareTo(name2) > 0) {
                    // Swap
                    Student temp = students[j];
                    students[j]     = students[j + 1];
                    students[j + 1] = temp;
                }
            }
        }
    }
 
    // ── CRUD ───────────────────────────────────────────────────────────────
 
    /**
     * Find a student by ID.
     * @throws StudentNotFoundException if no match
     */
    public Student findById(String id) throws StudentNotFoundException {
        for (int i = 0; i < studentCount; i++) {
            if (students[i] != null && students[i].getId().equalsIgnoreCase(id)) {
                return students[i];
            }
        }
        throw new StudentNotFoundException(
            "Student with ID '" + id + "' was not found.", id);
    }
 
    /**
     * Search students by first name (partial, case-insensitive).
     * Returns count of matches placed into results[].
     */
    public int searchByName(String name, Student[] results, int maxResults) {
        int count = 0;
        String lower = name.toLowerCase();
        for (int i = 0; i < studentCount && count < maxResults; i++) {
            if (students[i] != null &&
                    students[i].getFirstName().toLowerCase().contains(lower)) {
                results[count++] = students[i];
            }
        }
        return count;
    }
 
    /**
     * Get all male students (sorted).
     */
    public int getMaleStudents(Student[] results) {
        int count = 0;
        for (int i = 0; i < studentCount; i++) {
            if (students[i] != null && students[i].getGender().equals("M")) {
                results[count++] = students[i];
            }
        }
        return count;
    }
 
    /**
     * Get all female students (sorted).
     */
    public int getFemaleStudents(Student[] results) {
        int count = 0;
        for (int i = 0; i < studentCount; i++) {
            if (students[i] != null && students[i].getGender().equals("F")) {
                results[count++] = students[i];
            }
        }
        return count;
    }
 
    /**
     * Display all students in a formatted table.
     */
    public void displayAllStudents() {
        if (studentCount == 0) {
            System.out.println("  No students loaded.");
            return;
        }
 
        System.out.println("┌────────┬──────────────────────┬──────────────────────┬──────┬────┐");
        System.out.println("│   ID   │       Full Name      │      Department      │ Year │ Gn │");
        System.out.println("├────────┼──────────────────────┼──────────────────────┼──────┼────┤");
 
        for (int i = 0; i < studentCount; i++) {
            Student s = students[i];
            System.out.printf("│ %-6s │ %-20s │ %-20s │  %-3d │ %-2s │%n",
                    s.getId(),
                    s.getFullName(),
                    s.getDepartment(),
                    s.getYearOfStudy(),
                    s.getGender());
        }
 
        System.out.println("└────────┴──────────────────────┴──────────────────────┴──────┴────┘");
        System.out.printf("  Total students: %d%n", studentCount);
    }
 
    /**
     * Generate a text report of all students.
     */
    public String generateStudentReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("================================================\n");
        sb.append("       STUDENT REPORT - DORMITORY SYSTEM        \n");
        sb.append("================================================\n");
        sb.append(String.format("Total Students : %d%n%n", studentCount));
 
        for (int i = 0; i < studentCount; i++) {
            sb.append(students[i].generateReport());
            sb.append("----------------------------------\n");
        }
        return sb.toString();
    }
}