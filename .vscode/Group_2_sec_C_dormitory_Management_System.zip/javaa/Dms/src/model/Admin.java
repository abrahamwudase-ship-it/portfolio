package model;

/**
 * Admin class — extends User.
 * Represents a dormitory administrator with full system access.
 */
public class Admin extends User implements Reportable {

    private String staffId;
    private String officeLocation;

    public Admin(String id, String firstName, String lastName,
                 String username, String password,
                 String staffId, String officeLocation) {
        super(id, firstName, lastName, username, password);
        this.staffId = staffId;
        this.officeLocation = officeLocation;
    }

    // Getters & Setters
    public String getStaffId() { return staffId; }
    public void setStaffId(String staffId) { this.staffId = staffId; }

    public String getOfficeLocation() { return officeLocation; }
    public void setOfficeLocation(String officeLocation) { this.officeLocation = officeLocation; }

    // ── Overridden Abstract Methods ────────────────────────────────────────

    @Override
    public void displayInfo() {
        System.out.println("┌─────────────────────────────────────────┐");
        System.out.println("│           ADMIN INFORMATION             │");
        System.out.println("├─────────────────────────────────────────┤");
        System.out.printf("│  ID           : %-24s │%n", getId());
        System.out.printf("│  Name         : %-24s │%n", getFullName());
        System.out.printf("│  Staff ID     : %-24s │%n", staffId);
        System.out.printf("│  Office       : %-24s │%n", officeLocation);
        System.out.printf("│  Username     : %-24s │%n", getUsername());
        System.out.println("└─────────────────────────────────────────┘");
    }

    @Override
    public String getRole() {
        return "Admin";
    }

    @Override
    public void showMenu() {
        System.out.println("┌─────────────────────────────────────────┐");
        System.out.println("│              ADMIN MENU                 │");
        System.out.println("├─────────────────────────────────────────┤");
        System.out.println("│  1. View All Students                   │");
        System.out.println("│  2. Search Student                      │");
        System.out.println("│  3. Block & Room Management             │");
        System.out.println("│  4. Allocate Students to Rooms          │");
        System.out.println("│  5. Manage Complaints                   │");
        System.out.println("│  6. Generate Reports                    │");
        System.out.println("│  7. View Admin Info                     │");
        System.out.println("│  8. Exit                                │");
        System.out.println("└─────────────────────────────────────────┘");
    }

    // ── Reportable ─────────────────────────────────────────────────────────

    @Override
    public String generateReport() {
        return String.format(
            "ADMIN REPORT\n" +
            "============\n" +
            "Admin ID     : %s\n" +
            "Name         : %s\n" +
            "Staff ID     : %s\n" +
            "Office       : %s\n",
            getId(), getFullName(), staffId, officeLocation
        );
    }

    @Override
    public String getSummary() {
        return String.format("%-6s | %-20s | Staff: %-10s | Office: %s",
                getId(), getFullName(), staffId, officeLocation);
    }
}