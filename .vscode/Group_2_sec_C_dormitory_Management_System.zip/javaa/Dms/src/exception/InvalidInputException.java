package exception;

/**
 * Thrown when user input is invalid or out of expected range.
 */
public class InvalidInputException extends Exception {

    public InvalidInputException(String message) {
        super(message);
    }
}
