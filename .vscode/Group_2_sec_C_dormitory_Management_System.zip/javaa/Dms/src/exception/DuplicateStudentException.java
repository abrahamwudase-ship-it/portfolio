package exception;

/**
 * Thrown when a student with the same ID already exists in the system.
 */
public class DuplicateStudentException extends Exception {

    private String duplicateId;

    public DuplicateStudentException(String message) {
        super(message);
    }

    public DuplicateStudentException(String message, String duplicateId) {
        super(message);
        this.duplicateId = duplicateId;
    }

    public String getDuplicateId() {
        return duplicateId;
    }
}
